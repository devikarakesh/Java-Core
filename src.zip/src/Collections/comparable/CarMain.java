package Collections.comparable;

import java.util.TreeSet;

public class CarMain {
	public static void main(String[] args) {
		
		Car c=new Car(400);
		Car c2=new Car(200);
		
		TreeSet <Car> t=new TreeSet<>();
		t.add(c);
		t.add(c2);
		
		for(Car ca:t) {
			System.out.println(ca);
		}
	}

}
