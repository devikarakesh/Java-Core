package Collections.comparable;

import java.util.TreeSet;

public class MobileMain {
	public static void main(String[] args) {
			Mobile m=new Mobile("vivo",35000);
			Mobile m2=new Mobile("oppo",36000);
			Mobile m3=new Mobile("samsung",45000);
			
			TreeSet <Mobile> t=new TreeSet<>();
			t.add(m);
			t.add(m2);
			t.add(m3);
			
			for(Mobile mb:t) {
				System.out.println(mb);
			}
		}

}
