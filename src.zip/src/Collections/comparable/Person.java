package Collections.comparable;

public class Person implements Comparable<Person>{
	int height;
	String name;
	
	Person(int height,String name){
		this.height=height;
		this.name=name;
	}

	@Override
	public int compareTo(Person pe) {
		return this.height-pe.height;
	}
	
	public String toString() {
		return name+" "+height;
	}

}
