package Collections.comparable;

public class Mobile implements Comparable<Mobile>{
	String brand;
	Integer cost;
	
	Mobile(String brand,Integer cost){
		this.brand=brand;
		this.cost=cost;
	}

	@Override
	public int compareTo(Mobile mb) {
		return   mb.cost.compareTo(this.cost) &
				 mb.brand.compareTo(this.brand)
				;
	}
	public String toString() {
		return brand+" "+"cost:"+cost;
	}
}
