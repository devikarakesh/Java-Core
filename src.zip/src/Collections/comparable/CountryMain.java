package Collections.comparable;

import java.util.TreeSet;

public class CountryMain {
	public static void main(String[] args) {
		 Country c=new  Country("india");
		 Country c2=new Country("canada");
		 Country c3=new Country("china");
		
		TreeSet <Country> t=new TreeSet<>();
		t.add(c);
		t.add(c2);
		t.add(c3);
		
		for(Country ct:t) {
			System.out.println(ct);
		}
	}

}
