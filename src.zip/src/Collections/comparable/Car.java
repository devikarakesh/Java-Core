package Collections.comparable;

public class Car implements Comparable<Car>{
		int cost;
		
		Car(int cost) {
			this.cost=cost;
		}
			
	public int compareTo(Car x) {
		return this.cost-x.cost;
	}
	
	public String toString() {
		return "cost of car is:"+cost;
	}

}
