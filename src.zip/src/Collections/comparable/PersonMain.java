package Collections.comparable;

import java.util.TreeSet;

public class PersonMain {
	public static void main(String[] args) {
		Person p=new Person (150,"ram");
		Person p2=new Person(145,"niya");
		Person p3=new Person(160,"ciya");
		
		TreeSet <Person> t=new TreeSet<>();
		t.add(p);
		t.add(p2);
		t.add(p3);
		
		for(Person ps:t) {
			System.out.println(ps);
		}
	}

}
