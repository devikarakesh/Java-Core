package Collections.comparable;

public class Student implements Comparable<Student>{
	int age;
	String name;
	
	Student(int age,String name){
		this.age=age;
		this.name=name;
	}

	@Override
	public int compareTo(Student s) {
		return this.name.compareTo(s.name);
	}
	
	public String toString() {
		return name+" "+age;
	}
	

}
