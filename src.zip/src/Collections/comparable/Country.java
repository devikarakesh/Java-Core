package Collections.comparable;

public class Country implements Comparable <Country>{
	String name;
	
	Country(String name){
		this.name=name;
	}

	@Override
	public int compareTo(Country ct) {
		return ct.name.compareTo(this.name) ; //descending order => ct.name -compare to- this.name 
	}
	
	public String toString() {
		return "Country name:"+name;
	}

}
