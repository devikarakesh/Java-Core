package Collections.comparable;

import java.util.TreeSet;

public class StudentMain {
	public static void main(String[] args) {
		// objects creation
		Student s=new Student(20,"anu");
		Student s2=new Student(20,"meena");
		Student s3=new Student(22,"ciya");
		
		TreeSet <Student> t=new TreeSet<>();
		t.add(s);
		t.add(s2);
		t.add(s3);
		
		for(Student st:t) {
			System.out.println(st);
		}
	}

}
