package Collections.HashsetEg;

import java.util.HashSet;
import java.util.Iterator;

import Inheritance.hybrid.E;

public class Cities {
	public static void main(String[] args) {
		HashSet <String> set=new HashSet();
		set.add("kozhikode");
		set.add("chennai");
		set.add("bangalore");
		set.add("delhi");
		set.add("pune");
		
//		System.out.println(set);
		
		Iterator it=set.iterator();
		while(it.hasNext()) {
			System.out.println(it.next());
		}
		
	}

}
