package Collections.HashsetEg;

import java.util.HashSet;

public class Count {
	public static void main(String[] args) {
		String s="programming";
		HashSet <Character> hs=new HashSet();
		
		for(int i=0;i<s.length();i++) {
			char c=s.charAt(i);
			hs.add(c);
		}
		System.out.println("unique elem count:"+hs.size());	
	}
}
