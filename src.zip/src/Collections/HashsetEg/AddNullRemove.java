package Collections.HashsetEg;

import java.util.HashSet;
import java.util.LinkedHashSet;

public class AddNullRemove {
	public static void main(String[] args) {
		HashSet <String> hs=new HashSet();
		hs.add(null);
		System.out.println(hs);
		
//--------------------------------------------------------------
		Integer []arr= {5,2,3,2,4,5,1};
		LinkedHashSet <Integer> lsh=new LinkedHashSet();
		
		for(int i=0;i<arr.length;i++) {
			lsh.add(arr[i]);
		}
		System.out.println("after removing dupli:"+lsh);
	}

}
