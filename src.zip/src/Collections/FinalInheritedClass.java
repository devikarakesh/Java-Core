package Collections;

public final class FinalInheritedClass {
	void display() {
		System.out.println("final class inherited");
	}

}
