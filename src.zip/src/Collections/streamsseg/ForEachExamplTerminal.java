package Collections.streamsseg;

import java.util.stream.Stream;

public class ForEachExamplTerminal {
	public static void main(String[] args) {
		System.out.println("the stream forEach Operation:");
		
		Stream.iterate(1,e->e+1)
		.filter(e->e%5==0)
		.limit(10)
		.forEach(x->System.out.println(x));
		
	}
}
