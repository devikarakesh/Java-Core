package Collections.streamsseg;

import java.util.ArrayList;
import java.util.List;

public class StreamExampl {
	public static void main(String[] args) {
		
		List<Integer> li=new ArrayList<>();
		li.add(20);
		li.add(15);
		li.add(30);
		
		List<Integer>newList=li.stream()
				.map(n->n*2)
				.toList();
		
		System.out.println("original list:"+li);
		System.out.println("new list:"+newList);
		
	}

}
