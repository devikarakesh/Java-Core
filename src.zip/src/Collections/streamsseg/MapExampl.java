package Collections.streamsseg;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

public class MapExampl {
	public static void main(String[] args) {
		
		List<Integer>l=new ArrayList<>();
		l.add(10);
		l.add(5);
		l.add(9);
		
		List<Integer>nl=l.stream()
				.map(x->x*x)
				.collect(Collectors.toList());
		
		for(Integer i:nl) {
			System.out.println(i);
		}
	}

}
