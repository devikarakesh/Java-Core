package Collections.streamsseg;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

public class FiterExampl {
	public static void main(String[] args) {
		
		List<String>lt=new ArrayList<>();
		lt.add("meena");
		lt.add("sona");
		lt.add("jeena");
		
		List<String>s=lt.stream()
				.filter(x->x.startsWith("s"))
				.collect(Collectors.toList());// takes the result from stream and collect to new list
		 
		for(String i:s) {
			System.out.println(i);
		}
		
	}

}
