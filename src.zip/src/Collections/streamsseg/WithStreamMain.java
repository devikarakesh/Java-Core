package Collections.streamsseg;

import java.util.ArrayList;
import java.util.List;

public class WithStreamMain {
	public static void main(String[] args) {
		List<PgmWithStream>lt=new ArrayList<>();
		lt.add(new PgmWithStream(1, "hp laptop",35000f));
		lt.add(new PgmWithStream(1, "lenovo laptop",32000f));
		lt.add(new PgmWithStream(1, "samsung laptop",25000f));
		
		float totalPrice=lt.stream()
				.map(p->p.price)
				.reduce(0.0f,(sum,price)->sum+price);
		
		System.out.println(totalPrice);
	}
}
