package Collections.streamsseg;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

public class SoretedExampl {
	public static void main(String[] args) {
		
		List<String>l=new ArrayList<>();
		l.add("anu");
		l.add("ammu");
		l.add("sheeba");
		l.add("ciya");
		
		List<String>nl=l.stream().sorted().collect(Collectors.toList());
		
		for(String s:nl) {
			System.out.println(s);
		}
	}

}
