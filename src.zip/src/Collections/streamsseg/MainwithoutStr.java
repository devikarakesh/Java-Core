package Collections.streamsseg;

import java.util.ArrayList;
import java.util.List;

public class MainwithoutStr {
	public static void main(String[] args) {
		List<WithoutStreamPgm> ws=new ArrayList<>();
		
		ws.add(new WithoutStreamPgm(1,"HP laptop", 25000f));
		ws.add(new WithoutStreamPgm(2,"dell laptop", 30000f));
		ws.add(new WithoutStreamPgm(3,"lenovo laptop", 28000f));
		
//		for(WithoutStreamPgm wsp:ws) {
//			System.out.println(wsp);
//		}
		
		List<WithoutStreamPgm> pl=new ArrayList<WithoutStreamPgm>();
		
		for(WithoutStreamPgm pdt:ws) {
			if(pdt.price<30000) {
				pl.add(pdt);	
			}
		}
		System.out.println(pl);
		
	}
}
