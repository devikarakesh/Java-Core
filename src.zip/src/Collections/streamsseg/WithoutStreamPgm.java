package Collections.streamsseg;

public class WithoutStreamPgm {
	int id;
	String name;
	float price;
	
	public WithoutStreamPgm(int id,String name,float price) {
		this.id=id;
		this.name=name;
		this.price=price;
	}
	
	public String toString() {
		return id+" "+name+" "+price;
	}

}
