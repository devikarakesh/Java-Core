package Collections;

import java.util.LinkedList;

public class LinkedListSearch {
	public static void main(String[] args) {
		
		LinkedList <String> li=new LinkedList();
		
		li.add("india");
		li.add("china");
		li.add("us");
		
		String s="india";
		
		for(int i=0;i<li.size();i++) {
			if(li.get(i)==s) {
				System.out.println("element found");
				break;
			}
			else {
				System.out.println("element not found");
			}
		}
		
	}

}
