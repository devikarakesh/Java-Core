package Collections;

import java.util.Iterator;
import java.util.Stack;

public class StackNosEg {
	public static void main(String[] args) {
		Stack <Integer> st=new Stack<>();
		st.push(20);
		st.push(55);
		st.push(100);
		
		Iterator it =st.iterator();
		
		while(it.hasNext()) {
			System.out.println(it.next());
		}
		
		
	}

}
