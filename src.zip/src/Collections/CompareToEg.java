package Collections;

public class CompareToEg {
	public static void main(String[] args) {
		String a="miya";
		String b="neha";
		
	    System.out.println(a.compareTo(b));
	    System.out.println(b.compareTo(a));
	    System.out.println(b.compareTo(b));
		
		
		
//====================================================
		
		Integer x=10;
		Integer y=20;
		
		System.out.println(x.compareTo(y));
		System.out.println(y.compareTo(x));
		System.out.println(y.compareTo(y));
		
		
//=======================================================
		
		Double m=15.0;
		Double n=28.0;
		
		System.out.println(m.compareTo(n));
		System.out.println(n.compareTo(m));
		System.out.println(n.compareTo(n));
		
		
	}

}
