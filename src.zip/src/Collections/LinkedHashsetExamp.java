package Collections;


import java.util.Iterator;
import java.util.LinkedHashSet;

public class LinkedHashsetExamp {
	public static void main(String[] args) {
		LinkedHashSet <String> set=new LinkedHashSet();
		set.add("one");
		set.add("two");
		set.add("three");
		
		Iterator it=set.iterator();
		while(it.hasNext()) {
			System.out.println(it.next());
		}
	}

}
