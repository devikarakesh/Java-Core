package Collections;

import java.util.Vector;

public class VectorExample {
	public static void main(String[] args) {
		Vector <String> col=new Vector <>();
		
		col.add("red");
		col.add("green");
		col.add("yellow");
		col.add("grey");
		
		System.out.println("colors:"+col); //returns array format
		
		for(String s:col) {
			System.out.println(col);      //returns array format-4 elem added so 4 times array
		}
	}

}
