package Collections;

import java.util.ArrayList;
import java.util.Iterator;

public class ArrayListExample {
	public static void main(String[] args) {
		ArrayList <String> list=new ArrayList(); //creating ArrayList
		list.add("ram");                         // adding object in arraylist
		list.add("neha");
		list.add("priya");
		list.add("ciya");
		
//		list.remove(0);
//      list.remove("ciya");
//		list.set(0, "ammu");
		System.out.println(list.get(2));
		System.out.println(list.size());
		
		
		for(int i=0;i<list.size();i++) {
			System.out.println(list.get(i));
			
		}
		
//		Iterator itr=list.iterator();        // iterate list
//		
//		while(itr.hasNext()) {
//			System.out.println(itr.next());
//		}
	}

}
