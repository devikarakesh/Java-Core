package Collections;

import java.util.Iterator;
import java.util.Stack;

public class StackExample {
	public static void main(String[] args) {
		Stack <String> s =new Stack<>();
		s.push("mal");
		s.push("hindi");
		s.push("eng");
		
//		s.pop();
		System.out.println(s.peek());
		System.out.println(s.empty());
		
		Iterator it=s.iterator();
		while(it.hasNext()) {
			System.out.println(it.next());
		}
		
		
	}

}
