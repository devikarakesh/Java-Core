package Collections;

public class FinalClass extends Finaleg {
//	void display() {
//		System.out.println("override the final method in final class ");
//	}
	

}
