package Collections.comparatoeEg;

import java.util.TreeSet;

public class EmployeeSort {
	public static void main(String[] args) {
		Employee e=new Employee(1,"miya",35000);
		Employee e2=new Employee(2,"ram",30000);
		Employee e3=new Employee(3,"niya",32000);
	
	TreeSet <Employee> ts=new TreeSet<Employee>(new SortEmploBySal());
	ts.add(e);
	ts.add(e2);
	ts.add(e3);
	for(Employee ey:ts) {
		System.out.println(ey);
	}
	
	
	}
}
