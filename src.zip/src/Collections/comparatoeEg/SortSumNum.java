package Collections.comparatoeEg;

import java.util.Comparator;

public class SortSumNum implements Comparator<SumNumber>{

	@Override
	public int compare(SumNumber x, SumNumber y) {
		int diff=x.digSum-y.digSum;
		
		if (diff != 0) 
		return diff;
		 
		return x.num-y.num;
	}

}
