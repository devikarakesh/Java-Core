package Collections.comparatoeEg;

import java.util.TreeSet;

public class MainSort {
	public static void main(String[] args) {
		SumNumber s=new SumNumber(45);
		SumNumber s2=new SumNumber(30);
		SumNumber s3=new SumNumber(50);
		
		TreeSet <SumNumber> ts=new TreeSet<SumNumber>(new SortSumNum());
		ts.add(s);
		ts.add(s2);
		ts.add(s3);
		
		for(SumNumber sm:ts) {
			System.out.println(sm);
		}
	}

}
