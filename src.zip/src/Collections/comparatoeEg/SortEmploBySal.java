package Collections.comparatoeEg;

import java.util.Comparator;

public class SortEmploBySal implements Comparator<Employee> {

	@Override
	public int compare(Employee x, Employee y) {
		return x.salary-y.salary;
	}

}
