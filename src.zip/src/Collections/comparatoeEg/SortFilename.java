package Collections.comparatoeEg;

import java.util.Comparator;

public class SortFilename implements Comparator<Filename>{

	@Override
	public int compare(Filename x, Filename y) {
		return x.fname.compareTo(y.fname);
	}

}
