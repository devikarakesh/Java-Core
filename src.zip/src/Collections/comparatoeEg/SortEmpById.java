package Collections.comparatoeEg;

import java.util.Comparator;

public class SortEmpById implements Comparator <Employee> {

	@Override
	public int compare(Employee x, Employee y) {
		return x.id-y.id;
	}

}
