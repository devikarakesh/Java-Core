package Collections.comparatoeEg;

public class SumNumber {
	
	int num;
	int digSum;
	
	public SumNumber(int num) {
		this.num=num;
		int sum=0;
		int temp=num;
		
		while(temp>0) {
			int d=temp%10;
			sum=sum+d;
			temp=temp/10;
		}
		this.digSum=sum;
	}
	
	public String toString() {
		return num+"(sum="+digSum+")";
	}

}
