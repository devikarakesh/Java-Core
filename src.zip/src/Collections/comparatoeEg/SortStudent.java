package Collections.comparatoeEg;

import java.util.TreeSet;

public class SortStudent {
	public static void main(String[] args) {
		
		Student s=new Student(20,"ciya");
		Student s2=new Student(24,"teena");
		Student s3=new Student(23,"sona");
		
		TreeSet <Student> ts=new TreeSet<Student>(new SortStudentByname());
		ts.add(s);
		ts.add(s2);
		ts.add(s3);
		
		for(Student t:ts) {
			System.out.println(t);
		}
	}

}
