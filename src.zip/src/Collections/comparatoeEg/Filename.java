package Collections.comparatoeEg;

public class Filename {
	String fname;
	String fext;
	
	public Filename(String fname,String fext) {
		this.fname=fname;
		this.fext=fext;
	}
	
	public String toString() {
		return fname+fext;
	}

}
