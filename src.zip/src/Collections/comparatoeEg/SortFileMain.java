package Collections.comparatoeEg;

import java.util.TreeSet;

public class SortFileMain {
	public static void main(String[] args) {
		Filename f=new Filename("demo",".txt");
		Filename f2=new Filename("java",".jpeg");
		Filename f3=new Filename("python",".py");
		
		TreeSet <Filename> ts=new TreeSet<>(new SortFilename());
		ts.add(f);
		ts.add(f2);
		ts.add(f3);
		
		for(Filename fn:ts) {
			System.out.println(fn);
		}
	}

}
