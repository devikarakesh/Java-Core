package Collections;

import java.util.TreeSet;

public class TreeSetExampl {
	public static void main(String[] args) {
		TreeSet <Integer> ts=new TreeSet<>();
		
		ts.add(20);
		ts.add(85);
		ts.add(74);
		ts.add(10);
		
		for(Integer i:ts) {
			System.out.println(i);
		}
	
		System.out.println("=====================");
		TreeSet <Character> tsc=new TreeSet<>();
		tsc.add('Z');
		tsc.add('M');
		tsc.add('O');
		tsc.add('P');
		
		for(Character c:tsc) {
			System.out.println(c);
		}
		
		
	}

}
