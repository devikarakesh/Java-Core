package Collections;

import java.util.ArrayList;

public class ArrayListEvenNumb {
	public static void main(String[] args) {
		
		ArrayList <Integer> li=new ArrayList();
		
		li.add(10);
		li.add(25);
		li.add(30);
		li.add(21);
		li.add(50);
		
		for(int i=0;i<li.size();i++) {
			if(i%2==0) {
				System.out.println(li.get(i));
			}
		}
	}
}
