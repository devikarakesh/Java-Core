package Collections.PgmsStreamss;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

public class Duplicates {
	public static void main(String[] args) {
		List<Integer> li=new ArrayList<>();
		li.add(5);
		li.add(4);
		li.add(21);
		li.add(5);
		li.add(15);
		
		List <Integer> t=li.stream().distinct().collect(Collectors.toList());
		
		for(Integer n:t) {
			System.out.print(n+" ");
		}
	}

}
