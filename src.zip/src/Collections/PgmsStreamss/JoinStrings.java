package Collections.PgmsStreamss;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

public class JoinStrings {
	public static void main(String[] args) {
		List<String> li=new ArrayList<>();
		li.add("devika");
		li.add("rakesh");
		
		String j=li.stream()
				.collect(Collectors.joining());
		System.out.println(j);
		
	}

}
