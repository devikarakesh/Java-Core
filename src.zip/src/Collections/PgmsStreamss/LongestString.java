package Collections.PgmsStreamss;


import java.util.Arrays;
import java.util.Comparator;
import java.util.List;
import java.util.Optional;

public class LongestString {
	public static void main(String[] args) {
		List<String> li=Arrays.asList("keyboard","mouse","monitor");
		
		Optional<String> longStr=li.stream().
				          max(Comparator.comparingInt(s->s.length()));
				          
	    System.out.println(longStr);          
				          
				
	}

}
