package Collections.PgmsStreamss;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class MergeSorted {
	public static void main(String[] args) {
		List<Integer>li=new ArrayList<>();
		li.add(51);
		li.add(20);
		li.add(18);
		
		List<Integer> li2=new ArrayList<>();
		li2.add(11);
		li2.add(25);
		li2.add(36);
		
	
		List<Integer>mergedList=Stream.concat(li.stream(), li2.stream())
		              .sorted()
		              .collect(Collectors.toList());

		System.out.println(mergedList);


	        
		}
	}

