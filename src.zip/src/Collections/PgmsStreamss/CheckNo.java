package Collections.PgmsStreamss;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

public class CheckNo {
	public static void main(String[] args) {
		List <Integer> li=new ArrayList<>();
		li.add(110);
		li.add(20);
		li.add(55);
		
		List<Integer> lt=li.stream()
				.filter(n->n>50)
				.collect(Collectors.toList());
		
		for(Integer i:lt) {
			System.out.println(i);
		}
		
	}

}
