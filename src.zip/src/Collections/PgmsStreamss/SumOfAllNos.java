package Collections.PgmsStreamss;

import java.util.ArrayList;
import java.util.List;

public class SumOfAllNos {
	public static void main(String[] args) {
		List<Integer> li=new ArrayList<>();
		li.add(50);
		li.add(20);
		li.add(11);
		

		int sum = li.stream()
		          .reduce(0,(a,b)->a+b);

		System.out.println(sum);

	}

}
