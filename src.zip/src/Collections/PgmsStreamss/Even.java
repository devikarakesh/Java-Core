package Collections.PgmsStreamss;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

public class Even {
	public static void main(String[] args) {
		List<Integer>lt=new ArrayList<>();
		lt.add(35);
		lt.add(40);
		lt.add(72);
		lt.add(10);
		
		List<Integer> nl=lt.stream()
				.filter(n->n%2==0)
				.collect(Collectors.toList());
		
		for(Integer i:nl) {
			System.out.println(i);
		}
		
	}

}
