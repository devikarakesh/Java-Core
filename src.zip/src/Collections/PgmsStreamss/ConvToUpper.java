package Collections.PgmsStreamss;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

public class ConvToUpper {
	public static void main(String[] args) {
		List<String> li=new ArrayList<>();
		li.add("book");
		li.add("pen");
		li.add("scale");
		
		List<String> s=li.stream()
				.map(t->t.toUpperCase())
				.collect(Collectors.toList());
		
		for(String f:s) {
			System.out.println(f);
		}
	}

}
