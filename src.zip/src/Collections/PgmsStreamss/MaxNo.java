package Collections.PgmsStreamss;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

public class MaxNo {
	public static void main(String[] args) {
		List<Integer> li=Arrays.asList(10,85,62,20);
		Optional<Integer>in=li.stream()
				.reduce((a,b)->(a>b)?a:b);
		System.out.println(in);
		
		
	}

}
