package Collections.PgmsStreamss;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

public class SortedAscDesc {
	public static void main(String[] args) {
		List<Integer> li=new ArrayList<>();
		li.add(50);
		li.add(80);
		li.add(15);
		li.add(21);
		
		//ascending 
		List<Integer>ls=li.stream()
				.sorted()
				.collect(Collectors.toList());
		
		for(Integer st:ls) {
			System.out.println(st);
		}
		
		System.out.println("=============================");
		//descending 
		List<Integer> sortedDesc = li.stream()
                .sorted((a,b)->b-a)
                .collect(Collectors.toList());
		for(Integer stdesc:sortedDesc) {
			System.out.println(stdesc);
		}
			
	}
}
