package Collections.PgmsStreamss;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.stream.Collectors;

public class Intersection {
	public static void main(String[] args) {
		List<Integer> li=Arrays.asList(1,2,3,8,5);
		List<Integer> li2=Arrays.asList(1,3,7,6);
		
		List<Integer> nl=li.stream()
				.filter(x->li2.contains(x))
				.collect(Collectors.toList());
		
		System.out.println(nl);
	}

}
