package Collections.PgmsStreamss;

import java.util.ArrayList;
import java.util.List;

public class Count {
public static void main(String[] args) {
	List<Integer> i=new ArrayList<>();
	i.add(10);
	i.add(36);
	i.add(10);

	long count = i.stream().filter(n->n>5).count();
	
	System.out.println(count);


}
}
