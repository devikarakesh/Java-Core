package Collections.PgmsStreamss;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

public class SquareNos {
	public static void main(String[] args) {
		
		List<Integer> li=new ArrayList<>();
		li.add(6);
		li.add(8);
		li.add(5);
		
		List<Integer> nlt=li.stream()
				.map(n->n*n)
				.collect(Collectors.toList());
				
			for(Integer ig:nlt) {
				System.out.println(ig);
			}
		
		
	}

}
