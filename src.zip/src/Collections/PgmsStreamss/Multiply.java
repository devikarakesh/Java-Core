package Collections.PgmsStreamss;

import java.util.ArrayList;
import java.util.List;

public class Multiply {
	public static void main(String[] args) {
		List<Integer> i=new ArrayList<>();
		i.add(10);
		i.add(36);
		i.add(10);
		
		int mul=i.stream()
				.reduce(1,(a,b)->a*b);
		
		System.out.println(mul);
	}

}
