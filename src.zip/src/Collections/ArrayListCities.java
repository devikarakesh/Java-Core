package Collections;

import java.util.ArrayList;

public class ArrayListCities {
	public static void main(String[] args) {
		
		ArrayList <String> li=new ArrayList();
		
		li.add("mankavu");
		li.add("kotooli");
		li.add("edapally");
		
		
		for(String s:li) {
			System.out.println(s);
		}	
	}
}
