package Collections;

public class Finaleg  extends FinalInheritedClass{
	public static void main(String[] args) {
		
	final int a=10;
	a=20;
	System.out.println(a);

	}
	
	final void display() {
		System.out.println("this is a final method");
	}

}

