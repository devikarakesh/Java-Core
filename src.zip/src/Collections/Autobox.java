package Collections;

public class Autobox {
	public static void main(String[] args) {
		//Auto boxing
		int a=25;                    // primitive
		Integer m=new Integer(25);   // non-primitive
		System.out.println(a+" "+m);
		
		char c='C';
		Character d=new Character(c);
		System.out.println(c+" "+d);
		
		//Auto unboxing
		Integer x=new Integer(50);  // non-primitive
		int y=x;                    // primitive
		System.out.println(x+" "+y);
		
		
	}

}
