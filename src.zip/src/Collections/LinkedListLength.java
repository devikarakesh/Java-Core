package Collections;

import java.util.LinkedList;

public class LinkedListLength {
	public static void main(String[]args) {
		LinkedList <String> li= new LinkedList();
		
		li.add("ammu");
		li.add("devika");
		li.add("gayathri");
		
		for(int i=0;i<li.size();i++) {
			if(li.get(i).length()>5) {
				System.out.println(li.get(i));
			}
		}
	}
}
