package Collections;

import java.util.ArrayList; 
import java.util.Iterator;

public class ArrayListStudent {
	public static void main(String[] args) {
		
		ArrayList <String> li=new ArrayList();
		
		li.add("neha");
		li.add("liya");
		li.add("niya");
		li.add("ram");
		
		li.set(1,"ammu");
		
//		li.clear();
		System.out.println(li.isEmpty());
	
		Iterator it=li.iterator();
		
		while(it.hasNext()) {
			System.out.println(it.next());
		}	
	}
}
