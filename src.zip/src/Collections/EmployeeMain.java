package Collections;

import java.util.LinkedList;

public class EmployeeMain {
	public static void main(String[] args) {
		Employee e=new Employee("anu",20);
		Employee e1=new Employee("riya",22);
		Employee e2=new Employee("miya",24);
		
		
		LinkedList <Employee>l=new LinkedList<>();
		l.add(e);
		l.add(e1);
		l.add(e2);
		
		for(Employee i:l) {
			System.out.println(i);
		}
	}

}
