package Collections;

import java.util.Iterator;
import java.util.LinkedList;

public class LinkedListSum {
	public static void main(String[]args) {
		LinkedList <Integer> li=new LinkedList(); 
		li.add(15);
		li.add(23);
		li.add(20);
		li.add(11);
		
	 int sum=0;
	 for(int i=0;i<li.size();i++) {
		 sum=sum+li.get(i);
	 }
	 System.out.println("sum is:"+sum);
		
	 
//	 for(int n:li) {
//		 sum=sum+n;
//	 }
//	 System.out.println("sum is:"+sum);
//	}

}
}
