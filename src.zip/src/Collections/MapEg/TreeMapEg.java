package Collections.MapEg;

import java.util.Map.Entry;
import java.util.TreeMap;

public class TreeMapEg {
	public static void main(String[] args) {
		TreeMap<Integer,String> tm=new TreeMap<Integer,String>();
		tm.put(1,"pen");
		tm.put(2,"book");
		tm.put(3,"scale");
		System.out.println(tm);
		TreeMap<Integer,String> t=new TreeMap<Integer, String>();
		t.putAll(tm);
		System.out.println(t);
		
		System.out.println(tm.keySet());
		System.out.println(tm.values());
		System.out.println(tm.entrySet());
		
		//===extra methods for TreeMap====
		System.out.println(tm.firstKey());
		System.out.println(tm.firstEntry());
		System.out.println(tm.lastKey());
		System.out.println(tm.lastEntry());
		//===============================
		
		System.out.println(tm.containsKey(2));
		System.out.println(tm.containsValue("scale"));
		System.out.println(tm.get(2));
		System.out.println(tm.isEmpty());
		
		String r=tm.remove(2);
		System.out.println(r);
		
		boolean b=tm.remove(1,"pen");
		System.out.println(b);
		System.out.println(tm);
		
		//iterate
		System.out.println("KEYS:");
		for(Integer x :tm.keySet()) {
			System.out.print(x);
			System.out.print(",");
		}
		
		System.out.println("values:");
		for(String st:tm.values()) {
			System.out.print(st);
			System.out.print(",");
		}
		
		System.out.println("entry:");
		for(Entry<Integer,String> en:tm.entrySet()) {
			System.out.print(en);
			
			System.out.print(en.getKey()+" "+en.getValue());
			System.out.print(",");
		}
			
	}

}
