package Collections.MapEg;

import java.util.HashMap;
import java.util.Map.Entry;

public class HashMapEg {
	public static void main(String[] args) {
		HashMap <Integer,String>lang=new HashMap<>();
		
		lang.put(1,"java");
		lang.put(2, "python");
		lang.put(3,"javascript");
		System.out.println("hashmap:"+lang);
		
		//iterate over keys
		System.out.print("keys:");
		for(Integer key:lang.keySet()) {
			System.out.print(key);
			System.out.print(",");
		}
		
		//iterate through values
		System.out.println("\n values:");
		for(String value:lang.values()) {
			System.out.print(value);
			System.out.print(",");
		}
		
		//iterate through key/value entries
		System.out.print("\n entries:");
		for(Entry<Integer, String> entry:lang.entrySet()) {
          //	System.out.print(entry);
			System.out.print(entry.getKey()+" "+entry.getValue());
			System.out.print(",");	
		}
		
		// methods
		HashMap<Integer,String>hm=new HashMap<Integer, String>();
		hm.putAll(lang);
		System.out.println();
		System.out.println(hm);
		
		System.out.println(hm.keySet());
		System.out.println(hm.values());
		System.out.println(hm.entrySet());
		
		String r=hm.remove(1);
		System.out.println(r);
		System.out.println(hm);
		
		boolean rem=hm.remove(2,"python");
		System.out.println(rem);
		System.out.println(hm);
		
//		hm.clear();
//		System.out.println(hm);
		
		System.out.println(hm.containsKey(3));
		System.out.println(hm.containsValue("javascript"));
		
		System.out.println(hm.size());
		
		System.out.println(hm.isEmpty());
		System.out.println(hm.get(3));
		
		
		
	}

}
