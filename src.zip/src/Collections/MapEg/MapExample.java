package Collections.MapEg;

import java.util.Map.Entry;
import java.util.HashMap;
import java.util.Map;


public class MapExample {
	public static void main(String[] args) {
		Map<String,Integer>numb=new HashMap<>();
		numb.put("one",1);
		numb.put("two",2);
		numb.put("three",3);
		
		numb.putAll(numb);// copy everything from one map to another
		System.out.println("Map:"+numb);
		
		//accessing keys of map
		System.out.println(numb.keySet());
		//accessing values of map
		System.out.println(numb.values());
		//accessing entries of map
		System.out.println(numb.entrySet());
		
		//remove elements from map
		int value=numb.remove("two");
		System.out.println(value);
		System.out.println(numb);
		
		boolean rem=numb.remove("one",1);
		System.out.println(rem);
		
//		numb.clear();
//		System.out.println(numb);
		
		System.out.println(numb.containsKey("four"));
		System.out.println(numb.containsValue(3));
		
		System.out.println(numb.isEmpty());
		System.out.println(numb.get("three"));
		
		//equals()
		Map<Integer,String>a=new HashMap<>();
		a.put(1,"A");
		Map<Integer,String>b=new HashMap<>();
		b.put(1,"A");
		System.out.println(a.equals(b));
		
		// iterating
		System.out.println("KEYS");
		for(String i:numb.keySet()) {
			System.out.print(i);
			System.out.print(",");
		}
		
		System.out.println("VALUES");
		for(Integer in:numb.values()) {
			System.out.print(in);
			System.out.print(",");
		}
		
		System.out.println("ENTRIES");
		for(Entry<String,Integer> en:numb.entrySet()) {
			System.out.println(en);
			System.out.print(en.getKey()+" "+en.getValue());
			
		}
	}
}
