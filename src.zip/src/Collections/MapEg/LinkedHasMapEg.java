package Collections.MapEg;

import java.util.Map.Entry;
import java.util.LinkedHashMap;

public class LinkedHasMapEg {
	public static void main(String[] args) {
		LinkedHashMap <Integer,String> lhm=new LinkedHashMap<>();
		
		// methods
		lhm.put(1,"java");
		lhm.put(2, "c++");
		lhm.put(3, "php");
		
		System.out.println(lhm);
		
//		LinkedHashMap <Integer,String> l=new LinkedHashMap<Integer, String>();
//		l.putAll(lhm);
//		System.out.println(l);
		
		System.out.println(lhm.keySet());
		System.out.println(lhm.values());
		System.out.println(lhm.entrySet());
		
		String value=lhm.remove(2);
		System.out.println(value);
		System.out.println(lhm);
		
//		boolean rem=lhm.remove(1,"java");
//		System.out.println(rem);
		
//		lhm.clear();
//		System.out.println(lhm);
		
		System.out.println(lhm.containsKey(3));
		System.out.println(lhm.containsValue("java"));
		
		System.out.println(lhm.isEmpty());
		System.out.println(lhm.get(3));
		
		//equals
		LinkedHashMap<Integer,String> lh=new LinkedHashMap<Integer, String>();
		lh.put(1,"html");
		LinkedHashMap<Integer,String> lhe=new LinkedHashMap<Integer, String>();
		lhe.put(1,"html");
		
		System.out.println(lh.equals(lhe));
		
		//iterating
		System.out.println("KEYS");
		for(Integer key:lhm.keySet()) {
			System.out.print(key);
			System.out.print(",");
		}
		
		System.out.println("VALUES");
		for(String s:lhm.values()) {
			System.out.print(s);
			System.out.print(",");
		}
		
		System.out.println("ENTRIES");
		for(Entry<Integer, String> en:lhm.entrySet()) {
//			System.out.print(en);
//			System.out.print(",");
			System.out.println(en.getKey()+" "+en.getValue());
		}
		
		
	}

}
