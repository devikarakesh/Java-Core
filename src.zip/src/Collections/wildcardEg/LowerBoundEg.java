package Collections.wildcardEg;

import java.util.Arrays;
import java.util.List;

public class LowerBoundEg {
	public static void main(String[] args) {
		List<Integer> list1=Arrays.asList(4,5,6,7);
		
		//integer list object is being passed
		printOnlyIntegerClassorSuperClass(list1);

	List<Number>list2=Arrays.asList(4,5.5,6,7);
	
	//Number list object is being passed
	printOnlyIntegerClassorSuperClass(list2);
	}
	
	public static void printOnlyIntegerClassorSuperClass(List<? super Integer>list) {
		System.out.println(list);
	}
}

// the method printOnlyIntegerClassorSuperClass accepts only integer or its super classes (like number).
// if you try to pass a list if double it gives a compile time error because double is not a super class of integer

