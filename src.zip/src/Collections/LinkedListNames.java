package Collections;

import java.util.Iterator;
import java.util.LinkedList;

public class LinkedListNames {
	public static void main(String[] args) {
		
		LinkedList <String> li=new LinkedList();
		
		li.add("ram");
		li.add("ammu");
		li.add("abi");
		
		li.addFirst("sheeba");
		li.addLast("rakesh");
		
//		li.removeFirst();
//		li.removeLast();
		
		li.set(2,"gayathri");
		
		System.out.println(li.isEmpty());
		System.out.println(li.size());
		System.out.println(li.contains("ammu"));
		
		Iterator it=li.iterator();
		while(it.hasNext()) {
			System.out.println(it.next());
		}
		
	}

}
