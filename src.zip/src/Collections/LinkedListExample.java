package Collections;

import java.util.Iterator;
import java.util.LinkedList;

public class LinkedListExample {
	public static void main(String[] args) {
		LinkedList <String> li=new LinkedList();
		
		li.add("orange");
		li.add("mango");
		li.add("grapes");
		li.add("blueberry");
		li.add("mango");
		
		li.addFirst("banana");
		li.addLast("strawberry");
		
		li.set(0,"custardapple");
		
		System.out.println(li.isEmpty());
		System.out.println(li.size());
		
		System.out.println(li.contains("mango"));
		
//		li.removeFirst();
//		li.removeLast();
//		
//		li.remove(0);
//		li.remove("mango");
		
		System.out.println(li.get(1));
		System.out.println(li.getFirst());
		System.out.println(li.getLast());
		
//		Iterator it=li.iterator();
//		while(it.hasNext()) {
//			System.out.println(it.next());
//		}
		
	}

}
