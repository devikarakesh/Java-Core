package Collections;

import java.util.ArrayList;
import java.util.Iterator;

public class ArrayListIntegerExampl {
	public static void main(String[] args) {
		
		ArrayList <Integer> li=new ArrayList();
		
		li.add(1);
		li.add(2);
		li.add(3);
		li.add(4);
		
		Iterator it=li.iterator();
		
		while(it.hasNext()) {
			System.out.println(it.next());
		}
	}
}
