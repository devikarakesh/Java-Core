package Collections.lamdbaexp;

import java.util.*;

public class WithLambdaEg {
	public static void main(String[] args) {
		List<Integer> l=Arrays.asList(5,2,8,1);
		Collections.sort(l,(a,b)->a-b);
		System.out.println(l);
		
	}

}
