package Collections.lamdbaexp;

//functional interface
interface Greeting{
	void sayHello(String name);
}

public class LambdaExamp {
	public static void main(String[] args) {
		Greeting greet=(name)->System.out.println("Hello"+" "+name);
		greet.sayHello("devika");
	}


}
