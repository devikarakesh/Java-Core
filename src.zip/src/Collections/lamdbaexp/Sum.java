package Collections.lamdbaexp;

interface Calc{
	public int addnmul(int a,int b);
}


public class Sum {
	public static void main(String[] args) {
		Calc c=(a,b)->{
			int sum=a+b;
			int res=sum*2;
			return res;
		};
		System.out.println(c.addnmul(3, 8));
	
		
	}

}
