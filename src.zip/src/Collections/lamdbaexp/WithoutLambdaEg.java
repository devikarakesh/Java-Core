package Collections.lamdbaexp;

import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

public class WithoutLambdaEg {
	public static void main(String[] args) {

        List<Integer> l = Arrays.asList(5, 2, 8, 1);

        Collections.sort(l,new Comparator<Integer>() {
            @Override
            public int compare(Integer a, Integer b) {
                return a-b;
            }
        });

        System.out.println(l);
   
}


}
