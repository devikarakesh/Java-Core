package Collections.innerclsanonym;

public class Demo {
	    public static void main(String[] args) {

	        Runnable r = new Runnable() {
	            @Override
	            public void run() {
	                System.out.println("Hello");
	            }
	        };

	        r.run();
	    }
	}


