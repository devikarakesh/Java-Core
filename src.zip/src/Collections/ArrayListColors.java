package Collections;

import java.util.ArrayList;
import java.util.Iterator;

public class ArrayListColors {
	public static void main(String[] args) {
		
		ArrayList <String> li=new ArrayList();
		
		li.add("red");
		li.add("blue");
		li.add("yellow");
		li.add("purple");
		li.add("black");
		li.add("white");
	
		li.remove(1);
		li.set(2,"grey");
		System.out.println(li.size());
		
		Iterator it=li.iterator();
		
		while(it.hasNext()) {
			System.out.println(it.next());
		}	
	}
}
