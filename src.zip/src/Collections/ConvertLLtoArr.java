package Collections;

import java.util.LinkedList;


public class ConvertLLtoArr {
	public static void main(String[] args) {
		
		LinkedList<Integer>li=new LinkedList();
		li.add(10);
		li.add(15);
		li.add(20);
		
		Integer []arr=new Integer[li.size()];
		arr=li.toArray(arr);
		
		System.out.println("array elements:");
		for(int num:arr) {
			System.out.println(num);
		}
		
		
	}
}
