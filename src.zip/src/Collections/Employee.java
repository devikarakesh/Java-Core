package Collections;

public class Employee {
	String name;
	Integer id;
	
	public Employee(String name,Integer id) {
		this.name=name;
		this.id=id;
		
	}
	public String toString() {
		return name +"'s"+" "+"id is"+id;
	}
	

}
