package Collections;

import java.util.ArrayList;
import java.util.Iterator;

public class ArrayListFruits {
	public static void main(String[] args) {
		
		ArrayList <String> li=new ArrayList();
		
		li.add("mango");
		li.add("apple");
		li.add("orange");
		li.add("grapes");
		li.add("papaya");
		
		Iterator it=li.iterator();
		
		while(it.hasNext()) {
			System.out.println(it.next());
		}
	}

}
