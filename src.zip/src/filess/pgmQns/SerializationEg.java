package filess.pgmQns;

import java.io.Serializable;

public class SerializationEg implements Serializable {
	String name;
	
	public  SerializationEg(String name) {
		this.name=name;
	}
	
	public void display() {
		System.out.println("name is:"+name);
	}

}
