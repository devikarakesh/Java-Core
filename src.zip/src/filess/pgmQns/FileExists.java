package filess.pgmQns;

import java.io.File;
import java.io.IOException;
import java.util.Locale.Category;

public class FileExists {
	 public static void main(String[] args) {

	        File f = new File("java.txt");
	        try {
	        	if(f.createNewFile()) {
	        		System.out.println("file name:"+f.getName());
	        	}
	        if (f.exists()) {
	            System.out.println("File exists");
	            System.out.println("Name:"+f.getName());
	            System.out.println("Path:"+f.getAbsolutePath());
	            System.out.println("Size:"+f.length()+"bytes");
	        } else {
	            System.out.println("File does not exist");
	        }
	    }catch (IOException e) {
	    	e.printStackTrace();
	    }
		}
	}

