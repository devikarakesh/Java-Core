package filess.pgmQns;

import java.io.FileWriter;
import java.io.IOException;
import java.util.Scanner;

public class UserInput {
	public static void main(String[] args){
		Scanner sc=new Scanner(System.in);
		System.out.println("enter the text:");
		String text=sc.nextLine();
		
		try{
			FileWriter fw=new FileWriter("sample1.txt");
			fw.write(text);
			fw.close();
			System.out.println("written successfully");
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
}
