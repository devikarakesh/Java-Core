package filess.pgmQns;

import java.io.File;
import java.io.IOException;

public class NewFile {
	public static void main(String[]args) {
		File f= new File("sample.txt");
		try {
			if(f.createNewFile()) {
				System.out.println("File created:"+f.getName());
			}else {
				System.out.println("file already exists");
			}
		}catch (IOException e) {
			e.printStackTrace();
		}
	}

}
