package filess.pgmQns;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Scanner;

public class StudentDetails {
	public static void main(String[] args) {
		
	Scanner sc = new Scanner(System.in);
    String filename = "student.txt";

    try {
        FileWriter fw = new FileWriter(filename);
        System.out.println("Enter student id: ");
        int id=sc.nextInt();
        sc.nextLine(); 

        System.out.println("Enter student name: ");
        String name=sc.nextLine();

        System.out.println("Enter student marks: ");
        int marks=sc.nextInt();

        fw.write(id+" "+name+" "+marks);
        fw.close();

   //-------------------------------------------------------------
        File file = new File(filename);
        
        Scanner fr = new Scanner(file);

        System.out.println("Student details:");
        while (fr.hasNext()) {
            String studentId=fr.next();
            String studentName=fr.next();
            String studentMarks=fr.next();
            System.out.println(studentId + " " + studentName + " " + studentMarks);
        }

        fr.close();

    } catch(IOException e){
        e.printStackTrace();
    }
}
}

