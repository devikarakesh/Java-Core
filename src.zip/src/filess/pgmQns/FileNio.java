package filess.pgmQns;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;


public class FileNio {
    public static void main(String[] args) {
        Path dp=Paths.get("data/subdir");
        Path fp=Paths.get("data/subdir/sample.txt");

        try {
            Files.createDirectories(dp);
            Files.writeString(fp,"Java pgmg");
            System.out.println("Directory and file created");
        }catch (IOException e) {
            e.printStackTrace();
        }
    }

}
