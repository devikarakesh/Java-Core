package filess.pgmQns;

import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;

public class Object {
	public static void main(String[] args) {
		
		String filename="SerializationEg.ser";
		SerializationEg se=new SerializationEg("devika");
		
		try {
			ObjectOutputStream os=new ObjectOutputStream(new FileOutputStream(filename));
			os.writeObject(se);
			System.out.println("object has been serialized");
			se.display();
			
		}catch (IOException e) {
			e.printStackTrace();
		}
		
	}

}
