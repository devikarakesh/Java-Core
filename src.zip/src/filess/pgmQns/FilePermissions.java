package filess.pgmQns;

import java.io.File;
import java.io.IOException;

public class FilePermissions {
	public static void main(String[] args) {
		File f=new File("demo.txt");
		try {
			if(f.createNewFile()) {
				System.out.println("file name:"+f.getName());
			}else {
				System.out.println("file already existed");
				System.out.println(f.canRead());
				System.out.println(f.canWrite());
				System.out.println(f.canExecute());
			}
		}catch (IOException e) {
			e.printStackTrace();
		}
	}

}
