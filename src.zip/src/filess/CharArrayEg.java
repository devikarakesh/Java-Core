package filess;

import java.io.CharArrayReader;
import java.io.CharArrayWriter;
import java.io.IOException;

public class CharArrayEg {
	public static void main(String[] args) {
		//CharArrayWriter
		String message="this is charArray Eg";
		CharArrayWriter caw=new CharArrayWriter();
		 char[] charData=null;
		 
		try {
			caw.write(message);
			System.out.println("data written in CharArrayWriter");
		    charData=caw.toCharArray();
		}catch (IOException e) {
			e.printStackTrace();
		}
		
		//CharArrayReader
		try {
		CharArrayReader car=new CharArrayReader(charData);
		System.out.println("reading");
		int ch;
		while((ch=car.read())!=-1) {
			System.out.print((char)ch);
		}
		car.close();
		caw.close();
	  }catch (IOException e) {
		e.printStackTrace();
	  }
		
	}

}
