package filess;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;

public class ByteArray {
	public static void main(String[] args) {
		try {
			// -------------------ByteArrayO/p Stream
			ByteArrayOutputStream baos=new ByteArrayOutputStream();
			String message="Hello ByteArray Streams";
			baos.write(message.getBytes());// writing string as bytes
			//get the byte array
			byte[] byteArray=baos.toByteArray();
			
			// ------------------ByteArrayI/P stream
			ByteArrayInputStream bais=new ByteArrayInputStream(byteArray);
			
			int data;
			System.out.println("reading from ByteArrayInput Stream");
			while((data=bais.read())!=-1) {
				System.out.print((char)data);// convert byte to char
			}
			baos.close();
			bais.close();
			
		}catch (IOException e) {
			e.printStackTrace();
		}
	}

}
