package filess;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

public class BufferedWriterEg {
	public static void main(String[] args) {
		//--------------------------BufferedWriter
		String fileName="smaple.txt";
		try {
			BufferedWriter bf=new BufferedWriter(new FileWriter(fileName));
			// new FileWriter(fileName) - opening a file 
			bf.write("java i/o");
			bf.newLine();
			bf.write("buffered writer");
			System.out.println("writing done");
			bf.close();
		}catch(IOException e) {
			e.printStackTrace();
		}
		
		//------------------------BufferedReader
		try {
			BufferedReader br=new BufferedReader(new FileReader(fileName));
			System.out.println("reading contents");
			String line;
			while((line=br.readLine())!=null) {
				System.out.println("*"+line);	
			}
		}catch(IOException e) {
				e.printStackTrace();
		}
//==================================================================================
//		BufferedReader b=null;
//		try {
//			b=new BufferedReader(new FileReader(fileName));
//			System.out.println(b.readLine());
//		}catch(IOException e) {
//			e.printStackTrace();
//	}finally {
//		if(b!=null) {
//			b.close();
//		}catch(IOException e) {
//			e.printStackTrace();
//	}
//	}
//		}


	}

	}
