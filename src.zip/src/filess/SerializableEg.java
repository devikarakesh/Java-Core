package filess;

import java.io.Serializable;

public class SerializableEg implements Serializable {
	int id;
	String name;
	
	public SerializableEg(int id,String name) {
		this.id=id;
		this.name=name;
	}
	
	void display() {
		System.out.println("id is:"+id+" "+"name is:"+name);
	}
	

}
