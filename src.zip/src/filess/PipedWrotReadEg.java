package filess;

import java.io.IOException;
import java.io.PipedReader;
import java.io.PipedWriter;

public class PipedWrotReadEg {
	public static void main(String[] args) throws IOException {
		
		final PipedWriter pw=new PipedWriter();
		final PipedReader pr=new PipedReader(pw); // connect to writer reader 
		
		Thread writerThread=new Thread(()->{  // thread to write the data
			
		try {
			pw.write("msg passed through pipe");
			pw.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
		});
		//-------------------------------------------------------
		Thread readerThread=new Thread(()->{  // thread to read the data
			
			try {
				int data;
				System.out.println("reading from pipe:");
				while((data=pr.read())!=-1) {
					System.out.print((char)data);
				}
			} catch (IOException e) {
				e.printStackTrace();
			}
			});
		
		writerThread.start();   // start both threads
		readerThread.start();
		
		
	}

}
