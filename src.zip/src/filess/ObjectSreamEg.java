package filess;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInput;
import java.io.ObjectInputStream;
import java.io.ObjectOutput;
import java.io.ObjectOutputStream;

public class ObjectSreamEg {
	public static void main(String[] args) {
		String filename="SerializableEg.ser";
		
		SerializableEg se=new SerializableEg(101,"alice");
		
		//----------------serialization - object to bytestream
		
//		try(ObjectOutputStream oos=new ObjectOutputStream(new FileOutputStream(filename))){
//			oos.writeObject(se);
//			System.out.println("object has been serialized to:"+filename);
//		}catch (IOException e) {
//			e.printStackTrace();
//		}
		
		//---------------deserialization - bytestream to object 
		try(ObjectInputStream ois=new ObjectInputStream(new FileInputStream(filename))){
			SerializableEg se2=(SerializableEg)ois.readObject(); // casting
			System.out.println("object has been deserialized");
			se2.display();
		}catch (IOException | ClassNotFoundException e) {
		e.printStackTrace();
		}	
	}
}
