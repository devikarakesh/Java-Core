package filess;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;

public class FileIOExamapl {
	public static void main(String[] args) {
		
		String data="FileIO example successful";
		//fileoutputstream
		try {
			FileOutputStream fos=new FileOutputStream("example.txt");
			fos.write(data.getBytes());  //getBytes()- converts string to bytes
			fos.close();
			System.out.println("Data Written");
		}catch(IOException e) {
			e.printStackTrace();
		}
		
		//fileinputstream
		try{
			FileInputStream fis=new FileInputStream("example.txt");
			int bytedata;
			System.out.println("File content");
			while((bytedata=fis.read())!=-1) {
				System.out.print((char)bytedata);
			}
			fis.close();
		}catch(IOException e) {
			e.printStackTrace();
		}
	}

}
