package filess;

import java.io.File;
import java.io.IOException;

public class FileDemo {
	public static void main(String[] args) {
		
		File dir=new File("myFolder");
		if(dir.mkdir()) {
			System.out.println("Directory created:"+dir.getName());
		}else {
			System.out.println("directory already existed");
		}
	
//		File file=new File("example.txt");
		File file=new File(dir,"example.txt");
		try {
			if(file.createNewFile()) {
				System.out.println("File created:"+file.getName());
			}else {
				System.out.println("File already exists");
			}
			System.out.println("path:"+file.getAbsolutePath());
			System.out.println("writable:"+file.canWrite());
			System.out.println("readable:"+file.canRead());
			System.out.println("file size:"+file.length()+"bytes");
			System.out.println("file exists:"+file.exists());
			System.out.println(file.isFile());
			
			System.out.println(dir.isDirectory());
			
//			System.out.println(file.list());
		}
		catch(IOException e) {
			System.out.println("an error occurred");
			e.printStackTrace();
		}
	}

}
