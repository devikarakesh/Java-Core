package filess;

import java.io.BufferedOutputStream;
import java.io.FileOutputStream;
import java.io.IOException;

public class Buffered {
	public static void main(String[] args) {
		String data="FileIO example successful";
		
		// writing using BufferedO/p Stream
		try {
			FileOutputStream fos=new FileOutputStream("example.txt");
			BufferedOutputStream bos=new BufferedOutputStream(fos);
			bos.write(data.getBytes());
			bos.flush();// ensured all data is written
			bos.close();// also closes for internally
			System.out.println("data written");
		}catch (IOException e) {
			e.printStackTrace();
		}
	}

}
