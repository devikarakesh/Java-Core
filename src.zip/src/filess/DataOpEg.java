package filess;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;

public class DataOpEg {
	public static void main(String[] args) {
		String filename="data.txt";
		//--------------DataOutputStream
		try {
			DataOutputStream dos=new DataOutputStream(new FileOutputStream(filename));
			dos.writeInt(101);
			dos.writeBoolean(true);
			dos.writeDouble(55.87451);
			System.out.print("Data written");
		}catch (IOException e) {
			e.printStackTrace();
		}
		
		//------------DataInputStream
		try {
			DataInputStream dis=new DataInputStream(new FileInputStream(filename));
			int id=dis.readInt();
			double amt=dis.readDouble();
			boolean status=dis.readBoolean();
			System.out.println("reading from file");
			System.out.println("ID:"+id);
			System.out.println("Amount:"+amt);
			System.out.println("Status:"+status);
			
		}catch (IOException e) {
			e.printStackTrace();
		}
	}

}
