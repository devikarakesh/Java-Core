package filess;

import java.io.BufferedInputStream;
import java.io.FileInputStream;
import java.io.IOException;

public class BufferedInput {
	public static void main(String[] args) {
		//Reading using bufferedI/p Stream
		try {
			FileInputStream fis=new FileInputStream("example.txt");
			BufferedInputStream bis=new BufferedInputStream(fis);
			
			int byteData;
			while((byteData=bis.read())!=-1) {
				System.out.print((char)byteData);
			}
			bis.close();
		}catch (IOException e) {
			e.printStackTrace();
		}
	}

}
