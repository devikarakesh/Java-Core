package filess;

import java.io.FileNotFoundException;

import java.io.PrintStream;

public class PrintStreamEg {
	public static void main(String[] args) {
		try {
			PrintStream ps=new PrintStream("output.txt");
			ps.println("hii");
			ps.println(12345);
			ps.print(99.99);
			ps.print(true);
			
//			ps.printf("formatted:%s=%d\n","age",25);
			
			System.out.printf("formatted:%s=%d\n","age",25);
			ps.close();
			System.out.println("data written");
		}catch (FileNotFoundException e) {
			e.printStackTrace();
			
		}
	}

}
