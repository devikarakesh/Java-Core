package filess;

import java.io.IOException;
import java.nio.file.FileAlreadyExistsException;
import java.nio.file.Files;
import java.nio.file.LinkOption;
import java.nio.file.Path;
import java.nio.file.Paths;

public class FilesNioeg {
	public static void main(String[] args) {
//		Path path=Paths.get("data/logging.properties");
//		boolean pathExists=Files.exists(path,new LinkOption[] {LinkOption.NOFOLLOW_LINKS});
		
		Path path1=Paths.get("data/subdir");
		try {
			Files.createDirectory(path1);
			System.out.println("directory created");
			
		}catch (FileAlreadyExistsException e) {
			
		}catch (IOException e) {
			e.printStackTrace();
		}	
	}
}
