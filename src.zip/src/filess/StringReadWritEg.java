package filess;

import java.io.IOException;
import java.io.StringReader;
import java.io.StringWriter;

public class StringReadWritEg {
	public static void main(String[] args) {
		try {
			//-----------------StringWriter
			StringWriter sw=new StringWriter();
			sw.write("This is written to StringWriter");
			sw.write("Read this using StringReader");
			
			String data=sw.toString();
			
			//------------------StringReader
			StringReader sr=new StringReader(data);
			System.out.println("read using string reader");
			
			int ch;
			while((ch=sr.read())!=-1) {
				System.out.print((char)ch);
				
			}
		}catch (IOException e) {
			e.printStackTrace();
		}
	}

}
