package filess;


import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FilterInputStream;
import java.io.FilterOutputStream;
import java.io.IOException;

public class FilterOPEg {
	public static void main(String[] args) {
		String data="Hello from FilterOutputStream and FilterInputStream";
		//------------------FilterOutputStream
		try {
			FileOutputStream fos=new FileOutputStream("filter.txt");
			FilterOutputStream fosafil= new BufferedOutputStream(fos);
			
			fosafil.write(data.getBytes());
			fosafil.close();
			System.out.println("data written");
		}catch (IOException e) {
			e.printStackTrace();
		}
		
		//-----------------	FilterInputStream
		try {
			FileInputStream fis=new FileInputStream("filter.txt");
			FilterInputStream fil=new BufferedInputStream(fis);
			
			int ch;
			System.out.println("reading");
			while((ch=fil.read())!=-1) {
				System.out.print((char)ch);
			}
			fil.close();
			
		}catch (IOException e) {
			e.printStackTrace();
		
		}
	}

}
