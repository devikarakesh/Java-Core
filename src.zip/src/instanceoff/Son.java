package instanceoff;

public class Son extends Father{
	int age=23;
	

}
