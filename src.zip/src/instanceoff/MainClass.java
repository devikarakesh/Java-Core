package instanceoff;

public class MainClass {
	public static void display(India in) {
		if(in instanceof Kerala) {
			Kerala k=(Kerala)in;
			System.out.println("Chief Minister is:"+k.CM);
		}
		else if(in instanceof TamilNadu){
			TamilNadu tn=(TamilNadu)in;
			System.out.println("Chief Minister is:"+tn.CM);
		}
		else if(in instanceof Karnataka) {
			Karnataka kt=(Karnataka)in;
			System.out.println("Chief Minister is:"+kt.CM);
		}	
	}
	public static void main(String[] args) {
		display(new TamilNadu());
	}

}
