package instanceoff;

public class Daughter extends Father {
	int age=20;

}
