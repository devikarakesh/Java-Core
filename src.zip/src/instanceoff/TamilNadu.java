package instanceoff;

public class TamilNadu extends India{
	String CM="abc";
}
