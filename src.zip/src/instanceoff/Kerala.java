package instanceoff;

public class Kerala extends India{
	String CM="Pinarai Vijayan";
}
