package instanceoff;

public class Runner {
	public static void display(Father obj) {
		if(obj instanceof Son) {
			Son s =(Son)obj;
			System.out.println("son age is:"+s.age);
		}
		else if(obj instanceof Daughter) {
			Daughter d=(Daughter)obj;
			System.out.println("daughter age is:"+d.age);
		}
		else {
			System.out.println("father ase is:"+obj.age);
		}
	}
	
	public static void main(String[] args) {
		display(new Son());
	}
}
