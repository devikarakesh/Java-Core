package instanceoff;

public class Father {
	int age=45;

}
