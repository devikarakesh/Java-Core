package instanceoff;

public class Karnataka extends India {
	String CM="xyz";

}
