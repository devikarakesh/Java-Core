package instanceoff;

public class India {
	String PM="Narendra modi";
}
