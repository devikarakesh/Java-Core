package Execptionss;

public class Arrays {
	public static void main(String[] args) {
		int []x= {5,8,7,9,2};
		
		try {
			System.out.println(x[8]);
			
		}catch(ArrayIndexOutOfBoundsException e) {
			System.out.println("invalid index position");
		}
	}

}
