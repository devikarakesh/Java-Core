package Execptionss;

import java.util.Scanner;

public class Person {
	public static void main(String[]args) {
		
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter your age:");
		int age=sc.nextInt();
		if(age>=18) {
			System.out.println("Age to vote");
		}
		else {
			try {
				throw new AgeInvalidException("wait until 18");
			}catch(AgeInvalidException e) {
				System.out.println(e.getMessage());
			}
		}
	}
}
