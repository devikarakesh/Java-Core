package Execptionss;

import java.io.FileNotFoundException;
import java.io.FileReader;

public class Throwss {
	
	static void m1(int a,int b)throws ArithmeticException{
		System.out.println(a/b);
	}
	static void m2()throws InterruptedException{
		for(int i=0;i<10;i++) {
			System.out.println(i);
			Thread.sleep(2000);
		}
	}
	static void m3(String name)throws FileNotFoundException{
		FileReader fr=new FileReader(name);
	}
	
	public static void main(String[] args) {
		try {
//			m1(10,0);
//			m3("java.txt");
			m2();
		}catch(Exception e) {
			System.out.println(e.getMessage());
		}
	}

}
