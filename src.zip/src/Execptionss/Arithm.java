package Execptionss;

public class Arithm {
	public static void main(String[]args) {
//		int a=10,b=0;
//		int s=a/b;
//		System.out.println(s);
		
		
		int a=10,b=0;
		try {
			System.out.println(a/b);
		}catch(ArithmeticException e) {
			System.out.println("Do not divide by zero");
		}
	}

}
