package Execptionss;

public class MarkInvalidException extends Exception {
	public MarkInvalidException() {
		super();
	}

//	String message;
//	public MarkInvalidException(String message){
//		this.message=message;
//	}
//	
//	@Override
//	public String getMessage() {
//		return message;
//	}
}
