package Execptionss;

import java.util.Scanner;

public class Student {
	public static void main(String[] args) {
		
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the marks obtained:");
		int m=sc.nextInt();
		if(m>=70&&m<=100) {
			System.out.println("apply for college");
		}
		else {
			try {
				throw new MarkInvalidException();
			}catch(MarkInvalidException e) {
				System.out.println("better luck next time");
			}
		}	
	}
}
