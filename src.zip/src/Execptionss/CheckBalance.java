package Execptionss;

import java.util.Scanner;

public class CheckBalance {
	//throw
	public static void main(String[] args) {
		
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter your balance amount:");
		int bal=sc.nextInt();
		
		if(bal>=2000) {
			System.out.println("Sufficient balance is maintained");
		}
		
		else {
			try {
				throw new InsufficientBalanceException("Insufficent balance");
			}catch(InsufficientBalanceException e) {
				System.out.println(e.getMessage());
			}
		}
	}
}
