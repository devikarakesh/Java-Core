package Execptionss;

import java.io.FileNotFoundException;
import java.io.FileReader;

public class FileNot {
	public static void main(String[] args) {
		try {
			FileReader fr=new FileReader("myjava.txt");
		}catch(FileNotFoundException e) {
			System.out.println("file not fouund");
		}
	}

}
