package Execptionss;

public class TestAssertion {
	public static void main(String[] args) {
		
		int age=2;
		
		assert age>=18:"age is less than 18";
		System.out.println("age is valid");
	}

}
