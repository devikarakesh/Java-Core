package Execptionss;

public class Finalyy {
	public static void main(String[] args) {
		try {
			System.out.println(10/0);
		}catch(ArithmeticException v) {
			System.out.println(v.getMessage());
		}finally {
			System.out.println("always get executed");
		}
	}
}
