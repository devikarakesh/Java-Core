package Execptionss;


public class AgeInvalidException extends Exception {
//custom/user-defined exception
	String message;
	public AgeInvalidException(String message) {
		this.message=message;
	}
	
	@Override
	public String getMessage() {
		return message;
	}
}
