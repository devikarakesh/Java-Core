package Execptionss;

public class NullPointer {
	public static void main(String[] args) {
		
		String name=null;
		
		//generalization - super class - exception
		try {
			System.out.println(name.length());
		}catch(Exception e) {
			System.out.println("invalid");
		}
		
		//specialization
		try {
			System.out.println(name.length());
		}catch(NullPointerException e){
			System.out.println("invalid");	
		}
		
		// multiple catch
		try {
			System.out.println(10/0);
		}catch(NullPointerException e) {
			System.out.println("invalid name");
		}catch(ArithmeticException n) {
			System.out.println("do not divde by 0");
		}catch(ArrayIndexOutOfBoundsException a) {
			System.out.println("invalid index");
		}catch(Exception d) {
			System.out.println("invalid");
		}
	}

}
