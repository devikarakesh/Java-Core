package encpasulation;

public class PersonMain {
	public static void main(String[] args) {
		Person p=new Person();
		p.setName(null);
		p.setAge(22);
		System.out.println("Person name:"+p.getName());
		System.out.println("Person Age:"+p.getAge());
	}

}
