package encpasulation;

public class Son1 extends Father1{
	public void walk() {
		System.out.println("walk");
	}

}
