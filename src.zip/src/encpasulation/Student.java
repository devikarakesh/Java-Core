package encpasulation;

public class Student {
	private int id;
	private String name;
	private int age;
	private int marks;
	
	public void setId(int id) {
		this.id=id;
	}
	public void setName(String name) {
		this.name=name;
	}
	public void setAge(int age) {
		this.age=age;
	}
	public void setMarks(int marks) {
		if(marks>80) {
			this.marks=marks;
		}
		else {
			System.out.println("invalid marks");
		}
	}
	
	public int getId() {
		return id;
	}
	public String getName() {
		return name;
	}
	public int getAge() {
		return age;
	}
	public int getMarks() {
		return marks;
	}

}
