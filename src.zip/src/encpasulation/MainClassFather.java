package encpasulation;

public class MainClassFather {
	public static void main(String[] args) {
		
		Father1 f=new Father1();
		Daughter d=new Daughter();
		Son1 s=new Son1();
		
		System.out.println(d instanceof Father1);
		System.out.println(s instanceof Father1);
		System.out.println(f instanceof Son1);
		System.out.println(new Son1() instanceof Father1);	
	}
}
