package encpasulation;

public class Bus extends Vehicle{
	@Override
	void start() {
		System.out.println("Bus will be started");
	}
	
	@Override
	void stop() {
		System.out.println("bus will be stopped");
	}

}
