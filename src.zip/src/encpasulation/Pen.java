package encpasulation;

public class Pen {
	void write() {
		System.out.println("writing");
	}
}
