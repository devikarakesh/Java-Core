package encpasulation;

public class Daughter extends Father1{
	public void walk() {
		System.out.println("walks");
	}

}
