package encpasulation;

public class Runner {
	public static void main(String[] args) {
		
		Student s=new Student();
		
		s.setId(1);
		s.setName("abc");
		s.setAge(21);
		s.setMarks(85);
		
		System.out.println("Student id:"+s.getId());
		System.out.println("Student name:"+s.getName());
		System.out.println("Student age:"+s.getAge());
		System.out.println("Student marks:"+s.getMarks());
	}
}
