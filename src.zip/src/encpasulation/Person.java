package encpasulation;

public class Person {
	
	private String name;
	private int age;
	
	public void setName(String name) {
		if(name==null) {
			 System.out.println("invalid name");
	   }else {
		  this.name=name;
	   }
	}
	
	public void setAge(int age) {
		if(age>18) {
			this.age=age;
		}
		else {
			System.out.println("invalid age");
		}
	}
	
	public String getName() {
		return name;
	}
	public int getAge() {
		return age;
	}

}
