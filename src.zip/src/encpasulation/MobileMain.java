package encpasulation;

public class MobileMain {
	public static void main(String[] args) {
		
		Mobile m=new Mobile();
		
		m.setName("vivo");
		m.setCost(60000);
		
		System.out.println("Mobile name:"+m.getName());
		System.out.println("mobile cost:"+m.getCost());
	}

}
