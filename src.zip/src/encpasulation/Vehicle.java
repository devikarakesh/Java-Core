package encpasulation;

public class Vehicle{
	String color="red";
	int speed=50;
	
	void start() {
		System.out.println("starting");
	}
	void stop() {
		System.out.println("stop");
	}

}
