package encpasulation;

public class Father1 {
	public void walk() {
		System.out.println("walking");
	}
}
