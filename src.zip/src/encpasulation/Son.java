package encpasulation;

public class Son extends Father {
	void study() {
		System.out.println("studyig");
	}

}
