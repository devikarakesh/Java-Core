package encpasulation;

public class MainClass {
	
	static Vehicle chooseVehicle(int choose) {
		if(choose==1) {
			return new Car();
		}
		else {
			return new Bus();
		}
	}
	public static void main(String[] args) {
		Vehicle v=chooseVehicle(2);  //generalization
		v.start();
		v.stop();
	}

}
