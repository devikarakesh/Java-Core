package encpasulation;

//Generalization
public class Runner1 {
	static Pen choosePen(int choose) {
		if(choose==1) {
			return new Inkpen();
		}
		else {
			return new SketchPen();
		}	
	}
	public static void main(String[] args) {
		Pen p=choosePen(1); //Generalization
		p.write();
		
	}

}
