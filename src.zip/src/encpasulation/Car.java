package encpasulation;

public class Car extends Vehicle{
	@Override
	void start() {
		System.out.println("car is starting");
	}
	
	@Override
	void stop() {
		System.out.println("car will be stopped");
	}

}
