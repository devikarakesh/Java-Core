package encpasulation;

public class Mobile {
	private String name;
	private int cost;
	
	public void setName(String name) {
		if(name==null) {
			System.out.println("invalid name");
		}
		else {
			this.name=name;
		}
	}
	
	public void setCost(int cost) {
		if(cost>50000) {
			this.cost=cost;
		}
		else {
			System.out.println("invalid cost");
		}	
	}	
	
	public int getCost() {
		return cost;
	}
	
	public String getName() {
		return name;
	}
}
