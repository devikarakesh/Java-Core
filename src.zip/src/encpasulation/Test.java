package encpasulation;

public class Test {
	public static void main(String[] args) {
		//upcasting
		Father f=new Son();// implicityly,specialization
		f.work();         // only parent class members can be accessed
		
		//downcasting
		Son s=(Son)f;
		s.work();
		s.study();
	}

}
