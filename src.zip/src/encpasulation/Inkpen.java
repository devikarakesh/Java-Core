package encpasulation;

public class Inkpen extends Pen{
	@Override
	void write() {
		System.out.println("writng using inkpen");
	}

}
