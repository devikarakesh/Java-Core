package encpasulation;

//non-primitive Type casting 
public class Father {
	void work() {
		System.out.println("working");
	}
	

}
