package encpasulation;

public class SketchPen extends Pen{
	@Override
	void write() {
		System.out.println("writing using sketchpen");
	}
}
