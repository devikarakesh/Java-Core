
public class Colors {
	public static void main(String[] args) {
		for(Col c:Col.values()) {
			System.out.println(c);
		}
		
	}
	enum Col{
		RED,GREEN,BLUE,VIOLET,GREY,WHITE,PINK;
	}
}
