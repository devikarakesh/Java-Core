package demo;
import java.util.*;

public class Calculator {
	public static int add(int a,int b) {
		int c=a+b;
		return c;
	}
	public static int sub(int a,int b) {
		int z=a-b;
		return z;
	}
	public static int mul(int a,int b) {
		int d=a*b;
		return d;
	}
	public static int div(int a,int b) {
		int i=a/b;
		return i;
	}
	public static void main(String [] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter 1st no:");
		int m=sc.nextInt();
		System.out.println("Enter 2nd no:");
		int n=sc.nextInt();
		System.out.println("sum is:"+add(m,n));
		System.out.println("Diff is:"+sub(m,n));
		System.out.println("Mult is:"+mul(m,n));
		System.out.println("Div is:"+div(m,n));
	}

}
