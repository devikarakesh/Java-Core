package demo;

public class Functions {
	
// return type - void
//======================================
//	public static void sum(int a,int b) {
//		int c=a+b;
//		System.out.println(c);
//		}
	
//	public static void main(String [] args) {
//		sum(5,9);
//	}

	
//return type - int
//=======================================
	public static int sum(int a,int b) {
		int c=a+b;
		return c;
	}
	public static void main(String [] args) {
//		int m=sum(5,8);
//		System.out.println(m);
		//or
		System.out.println(sum(2,8));
		
	}
}
