package demo;
import java.util.*;
public class Demo {
	public static void main(String [] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("enter the input");
		int a=sc.nextInt();
		System.out.println(a);
	}
}
