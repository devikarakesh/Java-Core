package demo;

public class Stringvar {
	public static void name(String name) {
		System.out.println("Hello"+" "+"i am "+name+" "+"from kerala");
	}
	public static void main(String [] args) {
		name("devika");		
	}
}
