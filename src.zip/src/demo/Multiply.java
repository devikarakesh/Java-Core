package demo;

public class Multiply {
	public static void mult(int a,int b) {
		int c=a*b;
		System.out.println("Multiplication :"+c);
	}
	public static void main(String [] args) {
		mult(3,8);
	}

}
