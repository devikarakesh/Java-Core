package demo;
import java.util.*;

public class Scannerfunction {
	public static void sum(int x,int y) {
		int d=x+y;
		System.out.println("sum is:"+d);
	}
	public static void main(String [] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter your 1st no:");
		int a=sc.nextInt();
		System.out.println("Enter your 2nd no:");
		int b=sc.nextInt();
		sum(a,b);
	}
}
