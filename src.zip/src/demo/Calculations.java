package demo;

public class Calculations {
	public static int add(int a,int b){
		int c=a+b;
		return c;
		
	}
	public static int subtract(int x,int y) {
		int z=x-y;
		return z;
	}
	
	public static int mul(int m,int n) {
		int o=m*n;
		return o;
	}
	
	public static int div(int e,int f) {
		int g=e/f;
		return g;
	}
	
	public static void main(String [] args) {
		System.out.println(add(5,6));
		System.out.println(subtract(5,3));
		System.out.println(mul(4,5));
		System.out.println(div(20,10));	
	}
}
