package demo;

public class Operator {

	public static void main(String [] args) {
//		String a=(2%2==0)?"even":"odd";
//		System.out.println(a);
		
//		int a=50;
//		int b=100;
//		int c=(a>b)?a:b;
//		System.out.println(c);
		
		int x=5;
		String c=(x>0)?"positive no":"negative no";
		System.out.println(c);	
	}
}
