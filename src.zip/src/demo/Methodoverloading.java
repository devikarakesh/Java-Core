package demo;

public class Methodoverloading {
	public static void name() {
		System.out.println("This is non parameterised method");
	}
	public static void name(int a) {
		System.out.println("the number is:"+a);	
	}
	public static void name(float b) {
		System.out.println("float value is:"+b);
	}
	public static void main(String [] args) {
		name();
		name(5);
		name(2.0f);
	}

}
