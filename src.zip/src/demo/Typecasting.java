package demo;

public class Typecasting {
	public static void main(String [] args) {
		
//Primitive type casting
// widening - small to big
//		int a=10;
//		System.out.println(a);
//		double b=a;
//		System.out.println(b);
		
//Narrowing - big  to small
//		int a=65;
//		char b=(char)a;
//		System.out.println(a);
//		System.out.println(b);
		
//		char b='A';
//		int c=(int)b;
//	    System.out.println(b);
//	    System.out.println(c);			
	}

}
