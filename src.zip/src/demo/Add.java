package demo;

public class Add {
	public static void addition(int a,int b){
		int c=a+b;
		System.out.println("sum is:"+c);
	}
	public static void main (String [] args) {
		addition(4,5);
	}
}
