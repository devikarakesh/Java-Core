package demo;

public class Arithmetic {
	public static void main(String [] args) {
//		int a=10;
//		int b=10;
//		int c=a*b;
//		System.out.println(c);
		
//pre increment	
//		int a=10;
//		int b=++a;
//		System.out.println(a);
//		System.out.println(b);
		
//post increment
//		int a=10;
//		int b=a++;
//		System.out.println(a);
//		System.out.println(b);

//problems:
//		int a=11;
//		int b=13;
//		int c=a++ + ++b;
//		System.out.println(c);
//		
//		int a=10;
//		int b=10;
//		int c=a++ + b++;
//		System.out.println(a);
//		System.out.println(b);
//		System.out.println(c);
//		
//		int a=2;
//		int b=3;
//		int c=1;
//		a=b++;
//		++a;
//		b=c++;
//		b++;
//		c=a++;
//		++c;
//		System.out.println(a+" "+b+" "+c);
		
		int a=2;
		int b=3;
		int c=1;
		a=a++ + ++b + c++;
		System.out.println(a+b +""+ c+b);
		
//		int a=2;
//		int b=3;
//		int c=1;
//		b=++a + c++;
//		c=b++ + ++a;
//		a=++c + b++;
//		System.out.println(++a +" "+ b++ +" "+ ++c);
		
		
		
	}
}
