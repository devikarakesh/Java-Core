package demo;

public class Bank {
	static int balance=500;
	public static void deposit(int b) {
		balance+=b;
		System.out.println("updated current balance:"+balance);
	}
	public static void withdraw(int w) {
		balance=balance-w;
		System.out.println("updated current balance:"+balance);
	}
	public static void check() {
		System.out.print("current balance:"+balance);
	}
	public static void main(String [] args) {
		deposit(2500);
		withdraw(500);
		check();
	}
}
