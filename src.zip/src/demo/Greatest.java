package demo;

public class Greatest {
	public static void numbers(int a,int b,int c) {
		String d=(a>b)?(a>c ?"a is greater":"c is greater"):(b>c ?"b is greater":"c is greater");
        System.out.println(d);
	}
	public static void main(String [] args) {
		numbers(5,6,7);
	}

}
