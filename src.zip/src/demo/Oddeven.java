package demo;

public class Oddeven {
	public static void odd(int n) {
		String a=(n%2==0)?"even":"odd"; 
		System.out.println("Given number is:"+a);
	}
	
	public static void main(String [] args) {
		odd(5);
	}

}
