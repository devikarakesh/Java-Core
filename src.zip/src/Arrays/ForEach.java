package Arrays;

public class ForEach {
	public static void main(String[]args) {
//		int[]n= {1,2,3,4};
//		for(int num:n) {
//			System.out.println(num);
//		}
		
		String []fruits= {"mango","strawberry"};
		for(String f:fruits) {
			System.out.println(f);
			
		}
	}

}
