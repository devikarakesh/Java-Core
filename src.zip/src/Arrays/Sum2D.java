package Arrays;

public class Sum2D {
	public static void main(String[] args) {
		int [][]num= {
				{1,4,5},
				{2,3,6}
		};
		int sum=0;
		for(int i=0;i<num.length;i++) {
			for(int j=0;j<num[i].length;j++) {
				sum=sum+num[i][j];	
			}
		}
		System.out.println("sum is:"+sum);
		System.out.println("-------------");
		
		//forEach
		int sum1=0;
		for(int [] row:num) {
			for(int col:row) {
				sum1=sum1+col;
			}
		}
		System.out.print(sum);
		
	}
}
