package Arrays;

public class TwoD {
	public static void main(String[]args) {
//		int [][]num;
//		int[][]num=new int[2][3];
		
		int [][]num= {
				{5,8,9},
				{2,5,7}
		};
		
		for(int i=0;i<num.length;i++) {
			for(int j=0;j<num[i].length;j++) {
				System.out.print(num[i][j]+" ");
			}
			System.out.println();
		}
		
		System.out.println("--------------------------");
		
		//for each
		for(int []row:num) {
			for(int col:row) {
				System.out.print(col+" ");
			}
			System.out.println();
		}	
	}
}
