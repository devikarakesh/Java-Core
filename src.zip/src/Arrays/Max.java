package Arrays;

import java.util.Scanner;

public class Max {
	public static void main(String[]args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("enter the size:");
		int a=sc.nextInt();
		int []x=new int[a];
		int max=x[0];
		System.out.println("enter the data:");
		for(int i=0;i<a;i++) {
			x[i]=sc.nextInt();	
		}
		for(int i=0;i<a;i++) {
			if(x[i]>max) {
				max=x[i];
			}
		}
		System.out.println("maximum element is:"+max);	
	}
}
