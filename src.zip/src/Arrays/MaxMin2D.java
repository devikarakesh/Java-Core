package Arrays;

public class MaxMin2D {
	public static void main(String[] args) {
		int [][]num= {
				{1,2,3},
				{4,5,6}
		};
		int max=num[0][0];
		int min=num[0][0];
		
		for(int i=0;i<num.length;i++) {
			for(int j=0;j<num[i].length;j++) {
				if(max<num[i][j]) {
					max=num[i][j];	
				}
				else if(num[i][j]>min){
					min=num[i][j];
				}	
			}
		}
		System.out.println("max is:"+max);
		System.out.println("min is:"+min);	
	}
}
