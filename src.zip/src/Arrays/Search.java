package Arrays;

import java.util.Scanner;

public class Search {
	public static void main(String[]args) {
		
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the size:");
		int s=sc.nextInt();
		System.out.println("Enter the elements:");
		int []n=new int[s];
		for(int i=0;i<s;i++) {
			n[i]=sc.nextInt();
		}
		System.out.println("enter the elememt to search:");
		int key=sc.nextInt();
		
		for(int i=0;i<s;i++) {
			if(n[i]==key) {
				System.out.println("Number found at the index:"+i);
				return;
			}
		}
		System.out.println("element not found");
	}
}
