package Arrays;

import java.util.Scanner;

public class Xshaped2DArray {
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the size of rows:");
		int a=sc.nextInt();
		System.out.println("Enter the size of cols:");
		int m=sc.nextInt();
		int[][]b=new int[a][m];
		
		for(int i=0;i<a;i++) {
			for(int j=0;j<m;j++) {
				b[i][j]=sc.nextInt();
			}
		}
		System.out.println("matrix:");
		for(int i=0;i<a;i++) {
			for(int j=0;j<m;j++) {
				System.out.print(b[i][j]+" ");
			}
			System.out.println();
		}
		
		System.out.println("X shaped elements in 2D array:");

		for (int i=0;i<a;i++) {        
		    for (int j=0;j< m;j++) {    

		        // print only diagonal elements
		        if (i == j || i + j == m - 1) {
		            System.out.print(b[i][j] + " ");
		        } else {
		            System.out.print("  ");  
		        }
		    }
		    System.out.println();           
		}

	}
}
