package Arrays;

public class Average {
	public static void main(String[] args) {
		
		int []num= {10,20,30};
		
		int sum=0;
		int avg=0;
		
		for(int i=0;i<num.length;i++) {
			sum=sum+num[i];
		}
		
		avg=sum/num.length;
		System.out.println("sum is:"+sum);
		System.out.println("average is:"+avg);
	}

}
