package Arrays;

public class OddEven {
	public static void main(String[] args) {
		
		int evencount=0;
		int oddcount=0;
		int []num= {11,20,41,50};
		System.out.print("even:");
		for(int i=0;i<num.length;i++) {
			if(num[i]%2==0) {
				System.out.print(num[i]+" ");
				evencount++;
			}
		}
		System.out.print("\ntotal count of even no's:"+evencount);
		
		
		System.out.print("\nOdd:");
		for(int i=0;i<num.length;i++) {
			if(num[i]%2!=0) {
				System.out.print(num[i]+" ");
				oddcount++;
			}
		}
		System.out.print("\ntotal count of odd no's:"+oddcount);	
	}
}
