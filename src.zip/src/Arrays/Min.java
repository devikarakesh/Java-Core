package Arrays;

import java.util.Scanner;

public class Min {
	public static void main(String[]args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the size:");
		int a=sc.nextInt();
		int []z=new int[a];
		System.out.println("enter the elements:");
		for(int i=0;i<a;i++) {
			z[i]=sc.nextInt();
		}
		int min=z[0];
		for(int i=0;i<a;i++) {
			if(z[i]<min) {
				min=z[i];
			}
		}
		System.out.println("minimum element is:"+min);
	}
}
