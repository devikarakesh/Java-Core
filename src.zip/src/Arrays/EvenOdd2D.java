package Arrays;

public class EvenOdd2D {
	public static void main(String[] args) {
		int [][]num= {
				{1,5,9},
				{2,4,8}
		};
		int evencount=0;
		int oddcount=0;
		
		System.out.println("even no's are:");
		for(int i=0;i<num.length;i++) {
			for(int j=0;j<num[i].length;j++) {
				if(num[i][j]%2==0) {
					System.out.println(num[i][j]+" ");
					evencount++;	
				}
			}
		}
		System.out.println("Even count:"+evencount);
		
		System.out.println("odd no's are:");
		for(int i=0;i<num.length;i++) {
			for(int j=0;j<num[i].length;j++) {
				if(num[i][j]%2!=0) {
					System.out.println(num[i][j]+" ");
					oddcount++;
				}
			}
		}
		System.out.println("odd count:"+oddcount);
		
	}

}
