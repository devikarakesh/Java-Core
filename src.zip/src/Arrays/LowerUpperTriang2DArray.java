package Arrays;

import java.util.Scanner;

public class LowerUpperTriang2DArray {
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("enter size row:");
		int a=sc.nextInt();
		System.out.println("enter size col:");
		int b=sc.nextInt();
		int [][]y=new int[a][b];
		
		for(int i=0;i<a;i++) {
			for(int j=0;j<b;j++) {
				y[i][j]=sc.nextInt();	
			}
			
		}
			System.out.println("matrix:");
			for(int i=0;i<a;i++) {
				for(int j=0;j<b;j++) {
					System.out.print(y[i][j]+" ");	
				}
				System.out.println();
			}
			

			System.out.println("Upper triang:");
			for(int i=0;i<a;i++) {
				for(int j=0;j<b;j++) {
					if(i<=j) {
						System.out.print(y[i][j]+" ");
					}
					else {
						System.out.print("  ");
						 
					}
				}
				
				System.out.println();
			}
			
//			System.out.println("Lower triang:");
//			for(int i=0;i<a;i++) {
//				for(int j=0;j<b;j++) {
//					if(i>=j) {
//						System.out.print(y[i][j]+" ");
//					}
//					else {
//						System.out.print(" ");
//						 
//					}
//				}
//				
//				System.out.println();
//			}
	}

}
