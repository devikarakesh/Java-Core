package Arrays;

public class Sample {
	public static void main(String[]args) {
		//array declaration
		int []arr;
		
		//Array creation
		int[]a;
		a=new int[5];
		
		//Declaration and creation
		int []b=new int[5];
		
		//Array initialization
		int []c= {10,20,30,40,50}; //inline
		//or
		int []z=new int[4];
		z[0]=1;
		z[1]=2;
		z[2]=3;
		z[3]=4;
		
		//Fetching
		int []x= {20,22,23};
//		System.out.println(x[2]);
		
		for(int i=0;i<3;i++) {
			System.out.println(x[i]);
		}
	}
}
