package Arrays;

public class Diagonal2DArray {
	public static void main(String[] args) {
		int [][]a= {
				{4,8},
				{6,5}
		};
		
		for(int i=0;i<a.length;i++) {
			for(int j=0;j<a[i].length;j++) {
				if(i==j) {
					System.out.print(a[i][j]+" ");
				}	
			}
		}
}
}