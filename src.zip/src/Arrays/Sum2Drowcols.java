package Arrays;

public class Sum2Drowcols {
	public static void main(String[] args) {
		int [][]num= {
				{2,5},
				{3,6}
		};
		
		//rowsum
		for(int i=0;i<num.length;i++) {
			int sum=0;
			for(int j=0;j<num[i].length;j++) {
				sum=sum+num[i][j];
			}
			System.out.println("sum:"+sum);
		}
		//colsum
		for(int j=0;j<num[0].length;j++) {
			int colsum=0;
			for(int i=0;i<num.length;i++) {
				colsum=colsum+num[i][j];
			}
			System.out.println("column "+j +"sum:"+colsum);
		}
	}

}
