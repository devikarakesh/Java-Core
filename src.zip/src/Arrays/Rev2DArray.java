package Arrays;

public class Rev2DArray {
	public static void main(String[] args) {
		int [][]n= {
				{9,8,7},
				{4,5,6},
		};
		
		for(int i=n.length-1;i>=0;i--) {
			for(int j=n[i].length-1;j>=0;j--) {
				System.out.print(n[i][j]+" ");	
			}
			System.out.println();
		}
	}
}
