package Arrays;

import java.util.Scanner;

public class Sum {
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the size:");
		int a=sc.nextInt();
		int []c=new int[a];
		int sum=0;
		System.out.println("enter the elements:");
		for(int i=0;i<a;i++) {
			c[i]=sc.nextInt();
		}
		for(int i=0;i<a;i++) {
			sum=sum+c[i];
		}
		System.out.println("sum is"+sum);	
	}
}
