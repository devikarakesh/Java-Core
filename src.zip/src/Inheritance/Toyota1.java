package Inheritance;

public class Toyota1 extends Car1{
	Toyota1(){
		super("Mahindra");
		System.out.println("Toyota is starting");
	}

}
