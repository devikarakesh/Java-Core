package Inheritance;

public class Person {
	String name;
	int age;
	
	void personalDetails(String name,int age) {
		this.name=name;
		this.age=age;	
	}
	
	void show() {
		System.out.println("Name:"+name);
		System.out.println("Age:"+age);
	}
	

}
