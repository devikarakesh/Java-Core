package Inheritance;

public class ClassMain {
	public static void main(String[]args) {
		Toyota t=new Toyota();
		
	}

}
