package Inheritance;

public class Car {
	// Implicit super calling stmt- non parameterized constructor
	Car(){
		System.out.println("car is starting");
	}
}
