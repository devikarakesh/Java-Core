package Inheritance;

public class Car1 {
	//Explicit super calling stmt - parameterized constructor
	Car1(String name){
		System.out.println("car is starting");
	}
}
