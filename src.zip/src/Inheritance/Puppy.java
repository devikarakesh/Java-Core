package Inheritance;

public class Puppy extends Dog {
	String name="Titu";
	void eat() {
		System.out.println(super.name);
	}
	public static void main(String[]args) {
		Puppy p=new Puppy();
		p.eat();
	}
}
