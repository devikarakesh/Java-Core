package Inheritance;

public class ClassMain1 {
	public static void main(String[]args) {
		Toyota1 t=new Toyota1();
	}
}
