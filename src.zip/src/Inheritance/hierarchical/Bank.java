package Inheritance.hierarchical;

public class Bank {
	void interest() {
		System.out.println("6% interest");
	}

}
