package Inheritance.hierarchical;

public class Sbi extends Bank{
	void interest() {
		System.out.println("sbi int:8%");
	}

}
