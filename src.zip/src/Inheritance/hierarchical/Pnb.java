package Inheritance.hierarchical;

public class Pnb extends Bank {
	void interest() {
		super.interest();
		System.out.println("Pnb int:5%");
	}
}
