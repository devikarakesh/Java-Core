package Inheritance.hierarchical;

public class MainBank {
	public static void main(String[]args) {
		Pnb p=new Pnb();
		p.interest();	
	}
}
