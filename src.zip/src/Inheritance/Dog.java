package Inheritance;

public class Dog {
	String name="Puff";
	void bark() {
		System.out.println("Barking");
		}
	

}
