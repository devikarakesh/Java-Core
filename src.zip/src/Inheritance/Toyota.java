package Inheritance;

public class Toyota extends Car {
	public Toyota(){
		System.out.println("Toyota is starting");
	}
}
