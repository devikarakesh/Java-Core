package Inheritance;

public class Stud extends Person {
	int id=1;
	
	void addDetails(String name,int age) {
		personalDetails(name,age);
	}
	
	void showDetails() {
		System.out.println("ID:"+id);
		show();
	}
	
	public static void main(String[]args) {
		Stud s=new Stud();
		s.addDetails("Sona",23);
		s.showDetails();
	}
}
