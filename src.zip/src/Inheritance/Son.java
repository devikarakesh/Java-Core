package Inheritance;

public class Son extends Father{
	void study() {
		System.out.println("studying");
	}
	public static void main(String[]args) {
		Son s=new Son();
		s.study();
		s.sleep();
		s.eat();
		System.out.println(s.eyes);
	}

}
