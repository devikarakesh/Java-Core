package Inheritance;

public class Dept {
	int deptid;
	String deptname;
	
	void deptdetails(int deptid,String deptname) {
		this.deptid=deptid;
		this.deptname=deptname;
	}
	
	void showDetails() {
		System.out.println("Dept id:"+deptid);
		System.out.println("Dept name:"+deptname);
	}
}
