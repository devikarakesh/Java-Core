package Inheritance.hybrid;

public class C extends B {
	void draw() {
		System.out.println("drwaing");
	}

}
