package Inheritance.hybrid;

public class A {
	void run() {
		System.out.println("running");
	}

}
