package Inheritance.hybrid;

public class E extends B{
	void sleep() {
		System.out.println("sleeping");
	}

}
