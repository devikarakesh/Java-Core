package Inheritance.hybrid;

public class B extends A{
	void walk() {
		System.out.println("walking");
	}

}
