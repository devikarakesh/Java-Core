package Inheritance.hybrid;

public class D extends B {
	void read() {
		System.out.println("reading");
	}

}
