package Inheritance.hybrid;

public class MainClass {
	public static void main(String[]args) {
		D d=new D();
		d.walk();
		d.read();
		d.run();
	}

}
