package Inheritance;

public class Student extends Dept {
	int studid=1;
	String studname="Anita";
	
	void addDeptdetails(int deptid,String deptname) {
		deptdetails(deptid,deptname);
	}
	
	void showStudent() {
		System.out.println("student id:"+studid);
		System.out.println("student name:"+studname);
		showDetails();
	}
	
	public static void main(String[]args) {
		Student s=new Student();
		s.addDeptdetails(1,"CS");
		s.showStudent();
	}
}
