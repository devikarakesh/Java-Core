package Inheritance.multilevel;

public class MainClass {
	public static void main(String[]args) {
		Son s=new Son();
		System.out.println(s.eyes);
		s.show();
		s.display();
		s.print();
	}
}
