package Inheritance.multilevel;

public class Grandfather {
	String eyes="blue";
	void show() {
		System.out.println("Grandfather");
	}

}
