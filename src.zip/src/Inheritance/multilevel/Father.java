package Inheritance.multilevel;

public class Father extends Grandfather {
	String fEyes="blue";
	void display() {
		System.out.println("Father");
	}

}
