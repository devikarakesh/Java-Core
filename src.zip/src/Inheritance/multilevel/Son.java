package Inheritance.multilevel;

public class Son extends Father{
	String sEyes="blue";
	void print() {
		System.out.println("son");
	}

}
