package Inheritance;

public class Father {
	String eyes="blue";
	void eat() {
		System.out.println("eating");
	}
	static void sleep() {
		System.out.println("sleeping");
	}

}
