
public class EnumwithSwitch {
	public static void main(String[] args) {
		Signal s=Signal.YELLOW;
		
		switch (s){
		case RED:System.out.println("stop");
		         break;
		case GREEN:System.out.println("GO");
		           break;
		case YELLOW:System.out.println("wait");
		            break;
		default:System.out.println("invalid");
		}
		
	}
	
	enum Signal{
		RED,GREEN,YELLOW;
	}

}
