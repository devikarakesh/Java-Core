package gui;

import java.awt.LayoutManager;

import javax.swing.JCheckBox;
import javax.swing.JFrame;

public class SwingCheckBoxEg {
	public static void main(String[] args) {
		JFrame f=new JFrame();
		JCheckBox c=new JCheckBox("C++");
		JCheckBox c2=new JCheckBox("java");
		c.setBounds(100, 100, 50, 50);
		c2.setBounds(120, 140, 50, 50);
		f.add(c);
		f.add(c2);
		f.setSize(800, 800);
		f.setLayout(null);
		f.setVisible(true);
	}

}
