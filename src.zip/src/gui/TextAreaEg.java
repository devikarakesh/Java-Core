package gui;

import java.awt.Frame;
import java.awt.TextArea;

public class TextAreaEg {
	TextAreaEg(){
		Frame f=new Frame();
		TextArea ta=new TextArea("textarea");
		ta.setBounds(50, 50, 100, 100);
		f.add(ta);
		f.setLayout(null);
		f.setVisible(true);
	
	}
	public static void main(String[] args) {
		TextAreaEg tg=new TextAreaEg();
		
	}

}
