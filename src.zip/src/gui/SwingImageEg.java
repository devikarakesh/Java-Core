package gui;

import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JLabel;

public class SwingImageEg  {
	public static void main(String[] args) {
		JFrame f=new JFrame("img display");
		
		ImageIcon i=new ImageIcon("photo.jpg");
		JLabel l=new JLabel(i);
		f.add(l);
		f.setSize(500, 500);
		
		f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		f.setVisible(true);
	}
	

}
