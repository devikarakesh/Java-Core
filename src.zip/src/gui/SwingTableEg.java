package gui;

import java.awt.FlowLayout;

import javax.swing.JFrame;
import javax.swing.JScrollPane;
import javax.swing.JTable;

public class SwingTableEg {
	public static void main(String[] args) {
		JFrame f=new JFrame();
		
		String data[][]= {{"101","anu","50000"},
				{"102","meenu","55000"},
				{"103","anie","65000"}  };
		
		String column[]= {"ID","NAME","SALARY"};
	
		JTable t=new JTable(data,column);
		t.setBounds(30, 40, 200, 300);
		
		JScrollPane sp=new JScrollPane(t);
		
		f.add(sp);
		
		f.setLayout(new FlowLayout());
		f.setSize(500, 500);
		f.setVisible(true);
			
		
	}

}
