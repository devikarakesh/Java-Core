package gui;

import java.awt.Button;
import java.awt.Frame;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;

public class GuiDemo extends Frame{
	public GuiDemo() {
		Button b=new Button("click me");
		b.setBounds(100, 200, 250, 150);
		add(b);
		setSize(300,300);
		setLayout(null);
		setVisible(true);
		
		addWindowListener(new WindowAdapter() {
			public void windowClosing(WindowEvent e) {
				dispose();
			}
		});
	}
	
	public static void main(String[] args) {
		GuiDemo d=new GuiDemo();
	}

}
