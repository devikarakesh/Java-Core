package gui;

import java.awt.LayoutManager;

import javax.swing.JButton;
import javax.swing.JFrame;

public class Simple {
	//JAVA SWING
	// using association
	Simple(){
		JFrame f=new JFrame();
		JButton b=new JButton("click");
		b.setBounds(100, 150, 80, 100);
		f.add(b);
		f.setSize(500, 500);
		f.setLayout(null);
		f.setVisible(true);
	}
	
	public static void main(String[] args) {
		new Simple();
	}

}
