package gui;

import java.awt.Color;

import javax.swing.DefaultListModel;
import javax.swing.JFrame;
import javax.swing.JList;

public class SwingListEg {
	public static void main(String[] args) {
		JFrame f=new JFrame();
		
		DefaultListModel<String> l1=new DefaultListModel<String>();
		l1.addElement("item1");
		l1.addElement("item2");
		l1.addElement("item3");
		l1.addElement("item4");
		
		JList<String> li=new JList<>(l1);
		li.setBounds(100, 100, 75, 75);
		
		f.getContentPane().setBackground(Color.yellow);
		
		f.add(li);
		f.setSize(500, 500);
		f.setLayout(null);
		f.setVisible(true);
		
	}

}
