package gui;

import javax.swing.JFrame;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;

public class SwingMenuEg {
	public static void main(String[] args) {
		JFrame f=new JFrame();
		
		JMenuBar mb=new JMenuBar();
		
		JMenu m=new JMenu("menu");
		JMenu sm=new JMenu("sub menu");
		
		JMenuItem i1=new JMenuItem("item 1");
		JMenuItem i2=new JMenuItem("item 2");
		JMenuItem i3=new JMenuItem("item 3");
		JMenuItem i4=new JMenuItem("item 4");
		
		m.add(i1);
		m.add(i2);
		
		sm.add(i3);
		sm.add(i4);
		
		m.add(sm);
		mb.add(m);
		
		f.setJMenuBar(mb);
		
		f.setSize(500, 500);
		f.setLayout(null);
		f.setVisible(true);
		
	}

}
