package gui.project;

import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JRadioButton;
import javax.swing.JTextArea;
import javax.swing.JTextField;

public class RegForm {
	public static void main(String[] args) {
		JFrame f=new JFrame("Registration Form");
		
		JLabel l=new JLabel("Student Registration Form");
		
		JLabel l1=new JLabel("Name");
		JLabel l2=new JLabel("DOB");	
		JLabel l3=new JLabel("Address");
		JLabel l4=new JLabel("Qualification");
		JLabel l5=new JLabel("Gender");
		JLabel l6=new JLabel("Language Known");
		
		JTextField t=new JTextField();
		JTextField t2=new JTextField();
		
		JTextArea ta=new JTextArea();
		
		JRadioButton r1=new JRadioButton("Male");
		JRadioButton r2=new JRadioButton("Female");
		
		String []q= {"BCA","BTECH","BSC CS"};
		JComboBox co=new JComboBox(q);
		
		JCheckBox  cb1=new JCheckBox("Malayalam");
		JCheckBox  cb2=new JCheckBox("Hindi");
		JCheckBox  cb3=new JCheckBox("English");
		
		JButton b=new JButton("Submit");
		
		l.setBounds(140, 10, 220, 80);
		
		l1.setBounds(50, 70, 100, 30);
	    l2.setBounds(50, 110, 100, 30);
	    l3.setBounds(50, 150, 100, 30);
	    l4.setBounds(50, 200, 100, 30);
        l5.setBounds(50, 240, 100, 30);
	    l6.setBounds(50, 280, 150, 30);

	    t.setBounds(200, 80, 200, 30);
	    t2.setBounds(200, 120, 200, 30);

	    ta.setBounds(200, 160, 200, 30);

	    co.setBounds(200, 200, 200, 30);

	    r1.setBounds(200, 240, 80, 30);
	    r2.setBounds(290, 240, 100, 30);

	    cb1.setBounds(200, 280, 100, 30);
	    cb2.setBounds(310, 280, 80, 30);
	    cb3.setBounds(400, 280, 90, 30);

	    b.setBounds(180, 340, 100, 30);
		
		f.add(l);f.add(l1);f.add(l2);
		f.add(l3);f.add(l4);
		f.add(l5);f.add(l6);
		f.add(t);f.add(t2);
        f.add(ta);
        f.add(co);
        f.add(r1);f.add(r2);
        f.add(cb1);f.add(cb2);f.add(cb3);
        f.add(b);
		
		f.setSize(500, 500);
		f.setLayout(null);
		f.setVisible(true);
	}

}
