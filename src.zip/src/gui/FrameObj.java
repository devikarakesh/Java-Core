package gui;

import java.awt.Button;
import java.awt.Frame;

public class FrameObj {
	FrameObj() {
	Frame f=new Frame();
	Button b=new Button("click me");
	b.setBounds(30,50,80,30);
	f.add(b);
	f.setSize(300,300);
	f.setLayout(null);
	f.setVisible(true);
	}
	
	public static void main(String[] args) {
		FrameObj fo=new FrameObj();
	}

}
