package gui;

import javax.swing.JFrame;
import javax.swing.JRadioButton;

public class SwingRadioButtonEg {
	public static void main(String[] args) {
		
		JFrame f=new JFrame();
		
		JRadioButton r=new JRadioButton("A)MALE");
		JRadioButton r2=new JRadioButton("B)FEMALE");
		
		r.setBounds(100, 100, 80, 80);
		r2.setBounds(130,150, 120, 80);
		
		f.add(r);
		f.add(r2);
		
		f.setSize(600, 600);
		f.setLayout(null);
		f.setVisible(true);
	}

}
