package gui.adapter;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;


public class WithInner {
	public static void main(String[] args) {
		JFrame f=new JFrame();
		f.setSize(500, 500);
		f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		JButton b=new JButton("click");
		JLabel l=new JLabel("button not clicked");
		
		b.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				l.setText("button clicked");
				
			}
		});
		
		JPanel jp=new JPanel();
		jp.add(b);
		jp.add(l);
		f.add(jp);
		
		f.setVisible(true);
	}

}
