package gui.adapter;

import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

import javax.swing.JFrame;
import javax.swing.JLabel;

public class WithAdapter {
	public static void main(String[] args) {
		JFrame f=new JFrame();
		f.setSize(300, 300);
		f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		JLabel l=new JLabel("click inside the frame:");
		f.add(l);
		
		f.addMouseListener(new MouseAdapter() {
			public void mouseClicked(MouseEvent e) {
				l.setText("clicked at x:"+e.getX()+","+"y:"+e.getY());
			}
		});
		
		f.setVisible(true);
	}

}
