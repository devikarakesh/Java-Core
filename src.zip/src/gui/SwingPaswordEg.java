package gui;

import javax.swing.JFrame;
import javax.swing.JPasswordField;

public class SwingPaswordEg {
	public static void main(String[] args) {
		JFrame f=new JFrame();
		JPasswordField p=new JPasswordField();
		p.setBounds(100, 100, 100, 30);
		f.add(p);
		f.setSize(400, 500);
		f.setLayout(null);
		f.setVisible(true);
		
		
	}

}
