package gui;


import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.GridLayout;

import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JFrame;

public class SwingLayouts  {
	public static void main(String[] args) {
		JFrame f=new JFrame();
//		JButton b=new JButton("btn 1");
//		JButton b2=new JButton("btn 2");
//		JButton b3=new JButton("btn 3");
//		JButton b4=new JButton("btn 4");
//		JButton b5=new JButton("btn 5");
		
//		f.add(b);
//		f.add(b2);
//		f.add(b3);
//		f.add(b4);
//		f.add(b5);
		
//		f.setSize(500, 500);
//		f.setLayout(new FlowLayout());
		
//		f.setLayout(new GridLayout(2,3));
		
//		f.setLayout(new BorderLayout());
//		f.add(b,BorderLayout.NORTH);
//		f.add(b2,BorderLayout.EAST);
//		f.add(b3,BorderLayout.WEST);
//		f.add(b4,BorderLayout.CENTER);
//		f.add(b5,BorderLayout.SOUTH);
		
//		f.setLayout(new BoxLayout(f.getContentPane(),BoxLayout.X_AXIS));
		
		f.setLayout(new GridBagLayout());
		
		GridBagConstraints gbc=new GridBagConstraints();
		
		JButton b=new JButton("btn 1");
		JButton b2=new JButton("btn 2");
		JButton b3=new JButton("btn 3");

		
		gbc.gridx=0;
		gbc.gridy=0;
		f.add(b,gbc);
		
		gbc.gridx=1;
		gbc.gridy=0;
		f.add(b2,gbc);
		
		gbc.gridx=0;
		gbc.gridy=1;
		f.add(b3,gbc);
		
		f.setSize(300,300);
		f.setVisible(true);
	}

}
