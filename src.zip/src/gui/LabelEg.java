package gui;

import java.awt.Frame;
import java.awt.Label;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;

public class LabelEg {
	LabelEg(){
		Frame f=new Frame();
		Label l=new Label("enter your name");
		l.setBounds(50, 30, 150,180);
		f.add(l);
		f.setSize(300,300);
		f.setLayout(null);
		f.setVisible(true);
		
		f.addWindowListener(new WindowAdapter() {
			public void windowClosing(WindowEvent e) {
				f.dispose();
			}
		});
	
	}
	public static void main(String[] args) {
		LabelEg lg=new LabelEg();
		
	}

}
