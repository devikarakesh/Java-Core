package gui;

import java.awt.Checkbox;
import java.awt.Frame;

public class CheckboxEg {
	public CheckboxEg() {
		Frame f=new Frame();
		Checkbox cb=new Checkbox("java");
		cb.setBounds(50, 50, 80, 60);
		f.add(cb);
		f.setSize(500, 500);
		f.setLayout(null);
		f.setVisible(true);
		
	}
	public static void main(String[] args) {
		CheckboxEg c=new CheckboxEg();
				
	}

}
