package gui;

import java.awt.Frame;
import java.awt.Menu;
import java.awt.MenuBar;
import java.awt.MenuItem;

public class MenuEg {
	 MenuEg() {
		Frame f=new Frame();
		
		MenuBar mb=new MenuBar();
		Menu m=new Menu("Menu");
		Menu sm=new Menu("Submenu");
		
		MenuItem i1=new MenuItem("1");
		MenuItem i2= new MenuItem("2");
		MenuItem i3=new MenuItem("3");
		MenuItem i4=new MenuItem("4");
		MenuItem i5=new MenuItem("5");
		
		m.add(i1);
		m.add(i2);
		m.add(i3);
		
		sm.add(i4);
		sm.add(i5);
		
		m.add(sm);
		mb.add(m);
		
		f.setMenuBar(mb);
		
		f.setSize(500,500);
		f.setLayout(null);
		f.setVisible(true);
		
	
		
	}

	 public static void main(String[] args) {
		MenuEg mgg=new MenuEg();
	}
}
