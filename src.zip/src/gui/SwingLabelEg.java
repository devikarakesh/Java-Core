package gui;

import javax.swing.JFrame;
import javax.swing.JLabel;

public class SwingLabelEg {
	public static void main(String[] args) {
		JFrame f=new JFrame();
		JLabel l=new JLabel("First Label:");
		JLabel l2=new JLabel("Second label:");
		l.setBounds(50, 50, 100, 30);
		l2.setBounds(50,100,100,30);
		f.add(l);
		f.add(l2);
		f.setSize(400, 500);
		f.setLayout(null);
		f.setVisible(true);
		
		
	}

}
