package gui.eventhanEg;

import java.awt.Frame;
import java.awt.event.WindowEvent;

import java.awt.event.WindowListener;

public class WindowEg extends Frame implements WindowListener{
	public WindowEg() {
		addWindowListener(this);
		setSize(400, 400);
		setLayout(null);
		setVisible(true);
	}

	@Override
	public void windowOpened(WindowEvent e) {
		System.out.println("opened");
		
	}

	@Override
	public void windowClosing(WindowEvent e) {
	  System.out.println("closing");
	  dispose();
		
	}

	@Override
	public void windowClosed(WindowEvent e) {
		System.out.println("window closed");
		
	}

	@Override
	public void windowIconified(WindowEvent e) {
		System.out.println("iconified");
		
	}

	@Override
	public void windowDeiconified(WindowEvent e) {
		System.out.println("deiconified");
		
	}

	@Override
	public void windowActivated(WindowEvent e) {
		System.out.println("activated");
		
	}

	@Override
	public void windowDeactivated(WindowEvent e) {
		System.out.println("deactivated");
		
	}
	public static void main(String[] args) {
		new WindowEg();
	}

}
