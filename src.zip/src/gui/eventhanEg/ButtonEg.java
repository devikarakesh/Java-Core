package gui.eventhanEg;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JTextField;

public class ButtonEg {
	public static void main(String[] args) {
		JFrame f=new JFrame("ActionListener Eg");
		final JTextField tf=new JTextField();
		tf.setBounds(150, 100, 150, 50);
		JButton b=new JButton("click");
		b.setBounds(150, 200, 60, 30);
		
		b.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				tf.setText("welcome to java");
				
			}
		});
		f.add(b);
		f.add(tf);
		f.setLayout(null);
		f.setVisible(true);
	}

}
