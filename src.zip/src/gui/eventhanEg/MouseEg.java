package gui.eventhanEg;

import java.awt.Color;
import java.awt.Frame;
import java.awt.Graphics;
import java.awt.Label;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;

public class MouseEg  extends Frame implements MouseListener{
	
	Label l=new Label();
	
	public MouseEg() {
		addMouseListener(this);// registering method - making frame compatible ie; the mouse event changes need to reflect in frame
		l.setBounds(20, 50, 100, 20);
		add(l);
		setSize(500, 500);
		setLayout(null);
		setVisible(true);
	}

	@Override
	public void mouseClicked(MouseEvent e) {
		Graphics g=getGraphics();
		g.setColor(Color.blue);
		g.fillOval(e.getX(), e.getY(), 30, 30);
		
	}

	@Override
	public void mousePressed(MouseEvent e) {
		l.setText("mouse pressed");	
	}

	@Override
	public void mouseReleased(MouseEvent e) {
		l.setText("mouse released");
		
	}

	@Override
	public void mouseEntered(MouseEvent e) {
		l.setText("mouse enetered");
		
	}

	@Override
	public void mouseExited(MouseEvent e) {
	   l.setText("mouse exited");
		
	}
	public static void main(String[] args) {
		new MouseEg();
	}

}
