package gui.eventhanEg;

import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.security.Key;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JTextArea;
import javax.swing.JTextField;

public class KeyllistEg extends JFrame implements KeyListener {
	JLabel l;
	JTextArea a;
	KeyllistEg(){
		l=new JLabel();
		l.setBounds(20, 50, 200, 20);
		a=new JTextArea();
		a.setBounds(20, 80, 300, 300);
		
		a.addKeyListener(this);
		
		add(l);
		add(a);
		setSize(500,500);
		setLayout(null);
		setVisible(true);
	}
	@Override
	public void keyTyped(KeyEvent e) {
		l.setText("Key typed");
		
	}
	@Override
	public void keyPressed(KeyEvent e) {
		l.setText("key pressed");
	}
	
	@Override
	public void keyReleased(KeyEvent e) {
		String text=a.getText();
		String words []=text.split("\\s");
		l.setText("words:"+words.length+"characters:"+text.length());
	}
	
	public static void main(String[] args) {
		new KeyllistEg();
	}
	

}
