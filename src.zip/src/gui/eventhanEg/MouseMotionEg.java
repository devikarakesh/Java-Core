package gui.eventhanEg;

import java.awt.Color;
import java.awt.Frame;
import java.awt.Graphics;
import java.awt.Label;
import java.awt.event.MouseEvent;
import java.awt.event.MouseMotionListener;

public class MouseMotionEg extends Frame implements MouseMotionListener{
	
	Label l=new Label();
	
	MouseMotionEg() {
		addMouseMotionListener(this);
		l.setBounds(100, 150, 150, 50);
		add(l);
		setSize(400,400);
		setLayout(null);
		setVisible(true);
	}

	@Override
	public void mouseDragged(MouseEvent e) {
		Graphics g=getGraphics();
		g.setColor(Color.BLUE);
		g.fillOval(e.getX(),e.getY(), 25, 25);	
	}

	@Override
	public void mouseMoved(MouseEvent e) {
		l.setText("X="+e.getX()+","+"Y="+e.getY());
		
		
	}
	public static void main(String[] args) {
		new MouseMotionEg();
	}

}
