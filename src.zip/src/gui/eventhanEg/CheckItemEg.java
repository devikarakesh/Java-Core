package gui.eventhanEg;

import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;

import javax.swing.JCheckBox;
import javax.swing.JFrame;
import javax.swing.JTextField;

public class CheckItemEg extends JFrame implements ItemListener{
	
	
	 CheckItemEg() {
		JTextField t=new JTextField();
		JCheckBox cb2=new JCheckBox("java",true);
		JCheckBox cb1=new JCheckBox("C++");
		JCheckBox cb3=new JCheckBox("php");
		
		cb1.setBounds(200, 300, 80,50);
		cb2.setBounds(280, 300, 80,50);
		cb3.setBounds(370, 300, 80,50);
		add(cb1);
		add(cb2);
		add(cb3);
		
		
		t.setBounds(200, 350, 100, 30);
		add(t);
		setSize(500,500);
		setLayout(null);
		setVisible(true);
		

		cb1.addItemListener(new ItemListener() {
			@Override
			public void itemStateChanged(ItemEvent e) {
				if(e.getStateChange()==1) {
					t.setText(cb1.getText());
				}
				
			}
		});
		
	cb2.addItemListener(new ItemListener() {
	
	@Override
	public void itemStateChanged(ItemEvent e) {
		if(e.getStateChange()==1) {
			t.setText(cb2.getText());
		}
		
	}
});
cb3.addItemListener(new ItemListener() {
	
	@Override
	public void itemStateChanged(ItemEvent e) {
		if(e.getStateChange()==1) {
			t.setText(cb3.getText());
		}
		
	}
});
       
        
		
	}
	 
	 public static void main(String[] args) {
		new CheckItemEg();
	}
		 
	 


}
