package gui.eventhanEg;

import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;

import javax.swing.JCheckBox;
import javax.swing.JFrame;
import javax.swing.JTextField;

public class CheckBox {
	public static void main(String[] args) {
		JFrame jf=new JFrame("checkbox example");
		jf.setSize(600, 600);
		jf.setLayout(null);
		jf.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		JTextField t=new JTextField();
		t.setBounds(200, 350, 150, 30);
		jf.add(t);
		
		JCheckBox cb1=new JCheckBox("c++");
		JCheckBox cb2=new JCheckBox("java");
		JCheckBox cb3=new JCheckBox("php");
		cb1.setBounds(200, 300, 80, 30);
		cb2.setBounds(280, 300, 80, 30);
		cb3.setBounds(360, 300, 80, 30);
		
		jf.add(cb1);
		jf.add(cb2);
		jf.add(cb3);
		
		cb1.addItemListener(new ItemListener() {
			
			@Override
			public void itemStateChanged(ItemEvent e) {
				if(e.getStateChange()==1) {
					t.setText(cb1.getText());
				}
				
			}
		});
		
		cb2.addItemListener(new ItemListener() {
			
			@Override
			public void itemStateChanged(ItemEvent e) {
				if(e.getStateChange()==1) {
					t.setText(cb2.getText());
				}
				
			}
		});
		
		cb3.addItemListener(new ItemListener() {
			
			@Override
			public void itemStateChanged(ItemEvent e) {
				if(e.getStateChange()==1) {
					t.setText(cb3.getText());
				}
				
			}
		});
		
		jf.setVisible(true);
	}

}
