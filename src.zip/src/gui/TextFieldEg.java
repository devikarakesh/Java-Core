package gui;

import java.awt.Frame;
import java.awt.TextField;

public class TextFieldEg {
	TextFieldEg() {
		Frame f=new Frame();
		TextField t=new TextField("welcome");
		t.setBounds(30, 50, 150, 50);
		f.add(t);
		f.setSize(300,400);
		f.setLayout(null);
		f.setVisible(true);
		
	}
	public static void main(String[] args) {
		TextFieldEg to=new TextFieldEg();
	}

}
