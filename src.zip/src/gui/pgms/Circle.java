package gui.pgms;

import java.awt.Color;
import java.awt.Frame;
import java.awt.Graphics;
import java.awt.Label;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;

public class Circle extends Frame implements MouseListener{


	public Circle() {
		addMouseListener(this);
		setSize(500,500);
		setLayout(null);
		setVisible(true);
		
	}

	@Override
	public void mouseClicked(MouseEvent e) {
		Graphics g=getGraphics();
		g.setColor(Color.CYAN);
		g.fillOval(e.getX(), e.getY(),30, 30);
		
		
	}
	public static void main(String[] args) {
		new Circle();
	}

	@Override
	public void mousePressed(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void mouseReleased(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void mouseEntered(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void mouseExited(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}

	
	

}
