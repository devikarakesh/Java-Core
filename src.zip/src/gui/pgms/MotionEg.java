package gui.pgms;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.event.MouseEvent;
import java.awt.event.MouseMotionListener;

import javax.swing.JFrame;
import javax.swing.JLabel;

public class MotionEg extends JFrame implements MouseMotionListener{
   JLabel l=new JLabel();
	public MotionEg() {
		addMouseMotionListener(this);
		l.setBounds(200, 150, 150, 80);
		add(l);
		setSize(500, 500);
		setLayout(null);
		setVisible(true);
		
	}
	@Override
	public void mouseDragged(MouseEvent e) {
		Graphics g=getGraphics();
		g.setColor(Color.green);
		g.fillOval(e.getX(),e.getY(),30, 30);
		
	}

	@Override
	public void mouseMoved(MouseEvent e) {
		l.setText("X:"+e.getX()+","+"y:"+e.getY());
		
	}
	public static void main(String[] args) {
		new MotionEg();
	}
	

}
