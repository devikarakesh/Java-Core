package gui.pgms;

import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.awt.event.WindowListener;

import javax.swing.JFrame;
import javax.swing.JLabel;

public class AdapterEg {
	public static void main(String[] args) {
		
		JFrame f=new JFrame();
		
		JLabel l=new JLabel("enter your name");
		l.setBounds(80, 100, 150, 80);
		
		f.add(l);
		f.setSize(500, 500);
		f.setLayout(null);
		f.setVisible(true);
		
		f.addWindowListener(new WindowAdapter() {
			public void windowClosing(WindowEvent e) {
				f.dispose();	
			}
		});
	}

}
