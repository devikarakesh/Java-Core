package gui.pgms;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;

import javax.swing.JTextField;

public class CountBtnClick {
	
	static int count=0;
	
	public static void main(String[] args) {
		JFrame f=new JFrame();
		JButton b=new JButton("Click");
		JTextField t=new JTextField();
		
		b.setBounds(150, 120, 120, 50);
		t.setBounds(250, 200, 120, 50);
		
		b.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				count++;
				t.setText(" "+count);
			}
		});
		
		
		f.add(b);f.add(t);
		f.setSize(500, 500);
		f.setLayout(null);
		f.setVisible(true);
	}

}
