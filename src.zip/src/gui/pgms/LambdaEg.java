package gui.pgms;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JTextField;

public class LambdaEg {
	public static void main(String[] args) {
		JFrame f=new JFrame();
		JTextField t=new JTextField();
		JButton b=new JButton("click");
		
		t.setBounds(150, 120, 80, 30);
		b.setBounds(150, 200, 80, 30);
		
		b.addActionListener(e->t.setText("button clicked"));
		
		f.add(t);
		f.add(b);
		f.setSize(500, 500);
		f.setLayout(null);
		f.setVisible(true);
	}

}
