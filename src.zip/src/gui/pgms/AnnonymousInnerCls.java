package gui.pgms;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;

public class AnnonymousInnerCls {
	public static void main(String[] args) {
		JFrame f=new JFrame();
		JButton b=new JButton("click");
		
		b.setBounds(100, 120, 80, 30);
		
		b.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				System.out.println("button Clicked");
				
			}
		});
		
		f.add(b);
		f.setSize(500, 500);
		f.setLayout(null);
		f.setVisible(true);
	}

}
