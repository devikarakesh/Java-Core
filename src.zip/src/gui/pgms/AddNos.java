package gui.pgms;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JTextField;

public class AddNos {
	public static void main(String[] args) {
		JFrame f=new JFrame();
		JLabel l=new JLabel("enter the 1st no:");
		JLabel l2=new JLabel("enter the 2nd no:");
		JLabel l3=new JLabel("Result:");
		
		JTextField tf=new JTextField();
		JTextField tf2=new JTextField();
		JTextField tf3=new JTextField();
		
		JButton b=new JButton("Add");
		
	    l.setBounds(100, 100, 120, 30);
        l2.setBounds(100, 150, 120, 30);
        l3.setBounds(100, 200, 120, 30);
		
		
        tf.setBounds(230, 100, 150, 30);
        tf2.setBounds(230, 150, 150, 30);
        tf3.setBounds(230, 200, 150, 30);
        
        b.setBounds(200, 280, 80, 30);
        
        b.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				 int a=Integer.parseInt(tf.getText());
				 int b=Integer.parseInt(tf2.getText());
				 tf3.setText("" + (a + b));
				
			}
		});

		
		f.add(l);f.add(l2);f.add(l3);
		f.add(tf);f.add(tf2);f.add(tf3);
		f.add(b);
		
		f.setSize(600, 600);
		f.setLayout(null);
		f.setVisible(true);
		
	}
	

}
