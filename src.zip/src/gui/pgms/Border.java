package gui.pgms;

import java.awt.BorderLayout;

import javax.swing.JButton;
import javax.swing.JFrame;

public class Border {
	public static void main(String[] args) {
		JFrame f=new JFrame();
		JButton b=new JButton("btn  1");
		JButton b2=new JButton("btn 2");
		JButton b3=new JButton("btn 3");
		JButton b4=new JButton("btn 4");
		JButton b5=new JButton("btn 5");
		
		f.setSize(500, 500);
		f.setVisible(true);
		f.setLayout(new BorderLayout());
		
		f.add(b,BorderLayout.NORTH);
		f.add(b2,BorderLayout.SOUTH);
		f.add(b3,BorderLayout.EAST);
		f.add(b4,BorderLayout.CENTER);
		f.add(b5,BorderLayout.WEST);
		
	}

}
