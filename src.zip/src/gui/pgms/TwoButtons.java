package gui.pgms;

import javax.swing.JButton;
import javax.swing.JFrame;

public class TwoButtons {
	public static void main(String[] args) {
		JFrame f=new JFrame();
		JButton b=new JButton("Button 1");
		JButton b2=new JButton("Button 2");
		
		b.setBounds(150, 100, 100, 50);
		b2.setBounds(150,200, 100, 50);
		
		f.add(b); f.add(b2);
		
		f.setSize(500, 500);
		f.setLayout(null);
		f.setVisible(true);
	}

}
