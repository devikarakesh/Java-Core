package gui.pgms;

import java.awt.Color;
import java.awt.Frame;
import java.awt.Graphics;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;

public class Rectangle extends Frame implements MouseListener{
	public Rectangle() {
		addMouseListener(this);
		setSize(500,500);
		setLayout(null);
		setVisible(true);
	}

	@Override
	public void mouseClicked(MouseEvent e) {
		Graphics g=getGraphics();
		g.setColor(Color.darkGray);
		g.fillRect(e.getX(), e.getY(),150, 50);
		
	}

	@Override
	public void mousePressed(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void mouseReleased(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void mouseEntered(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void mouseExited(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}
	public static void main(String[] args) {
		new Rectangle();
	}
	

}
