package gui;

import java.awt.Choice;
import java.awt.Frame;

public class ChoiceEg {
	//choice - dropdown
	public ChoiceEg() {
		Frame f=new Frame();
		
		Choice c=new Choice();
		c.setBounds(50, 42, 80, 90);
		c.add("item 1");
		c.add("item 2");
		
		f.add(c);
		
		f.setSize(500, 500);
		f.setLayout(null);
		f.setVisible(true);
		
	}
	public static void main(String[] args) {
		ChoiceEg ce=new ChoiceEg();
	}

}
