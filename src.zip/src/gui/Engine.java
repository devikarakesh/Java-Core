package gui;

public class Engine {
	void start() {
		System.out.println("Engine started");
	}

}
