package gui;

import java.awt.Frame;
import java.awt.List;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;

public class ListEg {
	 ListEg() {
		Frame f=new Frame();
		
		List l1=new List(5);
		l1.setBounds(100, 100, 75, 75);
		l1.add("item 1");
		l1.add("item 2");
		l1.add("item 3");
		
		f.add(l1);
		
		f.setSize(500, 500);
		f.setLayout(null);
		f.setVisible(true);
		
		f.addWindowListener(new WindowAdapter() {
			public void windowClosing(WindowEvent e) {
				f.dispose();
			}
		});
	 }


	public static void main(String[] args) {
		ListEg lg=new ListEg();
	}

}
