package gui;

import javax.swing.JFrame;
import javax.swing.JTextField;

public class SwingTextFiledEg {
	public static void main(String[] args) {
		JFrame f=new JFrame();
		JTextField t=new JTextField("welcome");
		t.setBounds(50, 100, 200, 30);
		f.add(t);
		f.setSize(400, 500);
		f.setLayout(null);
		f.setVisible(true);
		
	}

}
