package gui;

import javax.swing.JFrame;
import javax.swing.JTextArea;

public class SwingTextAreaEg {
	public static void main(String[] args) {
		JFrame f=new JFrame();
		JTextArea a=new JTextArea("Java pgmng");
		a.setBounds(10, 30, 200, 200);
		f.add(a);
		f.setSize(500,400);
		f.setLayout(null);
		f.setVisible(true);
	}

}
