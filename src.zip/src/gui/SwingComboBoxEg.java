package gui;

import javax.swing.JComboBox;
import javax.swing.JFrame;

public class SwingComboBoxEg {
	// combobox = dropdown
	public static void main(String[] args) {
		JFrame f=new JFrame();
		
		String country[]= {"india","USA","UK","England"};
		JComboBox c=new JComboBox(country);
		
		c.setBounds(100, 150, 80, 20);
		f.add(c);
		f.setSize(500, 500);
		f.setLayout(null);
		f.setVisible(true);
		
	}

}
