package gui;

public class Car {
	//Association / has-a relationship Eg
	//Car has an Engine class object → this is called has-a relationship
	Engine en=new Engine();
	void drive() {
		en.start();
		System.out.println("car is driving");
	}
}
