
public class Enum11 {
	public static void main(String[] args) {
		Day d=Day.MONDAY;
		System.out.println(d);
		System.out.println(Day.TUESDAY.name());
		System.out.println(Day.THURSDAY.ordinal());
		
		for(Day d1:Day.values()) {
			System.out.println(d1);
		}
		
	}
	enum Day{
		MONDAY,TUESDAY,WEDNESDAY,THURSDAY,FRIDAY,SATURDAY,SUNDAY;
	}

}
