package Conditional;
import java.util.*;

public class Grade {
	public static void main(String [] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the marks");
		int m=sc.nextInt();
		if(m>=90) {
			System.out.println("A grade");
		}
		else if(m>75 && m<89) {
			System.out.println("B grade");
		}
		else if(m>50 && m<74) {
			System.out.println("C grade");
		}
		else{
			System.out.println("Fail");
		}
	}
	

}
