package Conditional;

public class Conditional {
	public static void main(String [] args) {

// simple if
//	int a=10;
//	int b=20;
	
//	if(a<b) {
//		System.out.println("a is greater");
//		}
	// if else
//	if(a>b) {
//		System.out.println("a is greater");
//	}
//	else {
//		System.out.println("b is greater");
//	}
	
	// if else if
//	int temp=17;
//	
//	if(temp>40) {
//		System.out.println("too hot");
//	}
//	else if(temp>30 && temp<40) {
//		System.out.println("warm");
//	}
//	else if(temp>20 && temp<30) {
//		System.out.println("normal");
//	}
//	else {
//		System.out.println("cold");
//	}
	
// nested if
	String username="admin";
	String password="123";
	
	if(username=="admin") {
		if(password=="123") {
			System.out.println("logged in");
		}
		else {
			System.out.println("password is incorrect");
		}
	}
	else {
			System.out.println("username is incorrect");
		}
	
	}
}
