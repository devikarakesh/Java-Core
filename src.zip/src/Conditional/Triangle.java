package Conditional;
import java.util.*;

public class Triangle {
	public static void Sides(int a,int b,int c) {
		if((a==b)&&(b==c)&&(a==c)) {
			System.out.println("Equilateral triangle");
		}
		else if((a==b)||(b==c)||(a==c)) {
			System.out.println("Isoceles triangle");
		}else {
			System.out.println("Scalene triangle");
		}
	}
	
	public static void main(String[]args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the 1st side:");
		int x=sc.nextInt();
		System.out.println("Enter the 2nd side:");
		int y=sc.nextInt();
		System.out.println("Enter the 3rd side:");
		int z=sc.nextInt();
		Sides(x,y,z);	
	}
}
