package Conditional;
import java.util.*;

public class Trafficsignal {
	public static void main(String [] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the input:");
		String a=sc.nextLine();
			if(a.equals("red")) {
				System.out.println("Stop");
			}
			else if(a.equals("yellow")) {
				System.out.println("Ready/Slow down");
			}
			else {
				System.out.println("Start");
			}
		}
}
