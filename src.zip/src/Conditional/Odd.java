package Conditional;
import java.util.*;

public class Odd {

// using return type void in function--
	
//	public static void odd(int n) {
//		if(n%2==0) {
//			System.out.println(n+" "+"is even number");
//		}
//		else {
//			System.out.println(n+" "+"is odd number");
//		}
//	}
	
//	public static void main(String [] args) {
//		Scanner sc=new Scanner (System.in);
//		System.out.println("Enter the number:");
//		int a=sc.nextInt();
//		odd(a);
//	}
	
// using return type int in function
	public static int oddoreven(int n) {
		if (n%2==0) {
			System.out.println(n+" "+"is  an even number");
		}
		else {
			System.out.println(n+" "+"is odd number");
		}
		return n; 
	}
	
	public static void main(String [] args) {
	Scanner sc=new Scanner (System.in);
	System.out.println("Enter the number:");
	int a=sc.nextInt();
	oddoreven(a);
}

// using only main method ,no function
//	public static void main(String [] args) {
//		Scanner sc=new Scanner (System.in);
//		System.out.println("Enter the number:");
//		int a=sc.nextInt();
//		if(a%2==0) {
//			System.out.println(a+" "+"is even number");
//		}
//		else {
//			System.out.println(a+" "+"is odd number");
//		}
//	}
}
