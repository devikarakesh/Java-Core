package Conditional;
import java.util.*;

public class Electricitybill {
	public static void Bill(int b) {
		int Surcharge;
		int net;
		if(b>500) {
			Surcharge=b*10/100;
			net=b+Surcharge;
			System.out.println("Surcharge:"+Surcharge);
			System.out.println("Net Amount:"+net);
		}
		else {
			System.out.println("Amount:"+b);
		}
	}
	public static void main(String [] args){
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the bill amount:");
		int a=sc.nextInt();
		Bill(a);
	}
}
