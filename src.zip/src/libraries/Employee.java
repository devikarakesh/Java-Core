package libraries;

public class Employee {
	int id;
	String name;
	int age;
	int salary;
	
	Employee(int id,String name,int age,int salary){
		this.id=id;
		this.name=name;
		this.age=age;
		this.salary=salary;
	}
	@Override
	public String toString() {
		return "ID is:"+id+" "+"name is:"+name+" "+"age is:"+age+" "+"salary is:"+salary;
	}

}
