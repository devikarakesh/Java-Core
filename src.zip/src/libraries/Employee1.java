package libraries;

public class Employee1 {
	int id;
	String name;
	Employee1(int id,String name){
		this.id=id;
		this.name=name;
	}
	@Override
	public boolean equals(Object obj) {
		Employee1 e=(Employee1)obj;
		return this.id==e.id || this.name==e.name;
	}

}
