package libraries;

public class EmployeeMain {
	public static void main(String[]args) {
		Employee1 e=new Employee1(1,"achu");
		Employee1 e2=new Employee1(1,"ram");
		
		System.out.println(e.equals(e2));
	}

}
