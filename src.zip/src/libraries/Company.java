package libraries;

public class Company {
	public static void main(String[] args) {
		Employee e=new Employee(1,"riya",23,25000);
		Employee e2=new Employee(2,"diya",25,28000);
		Employee e3=new Employee(3,"sona",24,25000);
		Employee e4=new Employee(4,"ram",23,27000);
		Employee e5=new Employee(5,"neha",24,26000);
		
		System.out.println(e);
		System.out.println(e2);
		System.out.println(e3);
		System.out.println(e4);
		System.out.println(e5);
	}

}
